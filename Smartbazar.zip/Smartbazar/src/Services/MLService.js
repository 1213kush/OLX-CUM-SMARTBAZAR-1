// ML Service API Integration
const API_BASE_URLS = {
  recommendations: 'http://localhost:5001/api/recommendations',
  vision: 'http://localhost:5002/api/vision'
};

class MLService {
  constructor() {
    this.recommendationsLoaded = false;
    this.visionModelLoaded = false;
  }

  // Recommendation Service Methods
  async loadRecommendationModels() {
    try {
      const response = await fetch(`${API_BASE_URLS.recommendations}/load`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();
      if (data.status === 'success') {
        this.recommendationsLoaded = true;
      }
      return data;
    } catch (error) {
      console.error('Error loading recommendation models:', error);
      return { status: 'error', message: error.message };
    }
  }

  async getUserBasedRecommendations(userIndex, count = 5) {
    try {
      const response = await fetch(
        `${API_BASE_URLS.recommendations}/user-based/${userIndex}?count=${count}`
      );
      return await response.json();
    } catch (error) {
      console.error('Error getting user-based recommendations:', error);
      return { status: 'error', message: error.message };
    }
  }

  async getSVDRecommendations(userIndex, count = 5) {
    try {
      const response = await fetch(
        `${API_BASE_URLS.recommendations}/svd/${userIndex}?count=${count}`
      );
      return await response.json();
    } catch (error) {
      console.error('Error getting SVD recommendations:', error);
      return { status: 'error', message: error.message };
    }
  }

  async getRankBasedRecommendations(count = 5, minInteractions = 10) {
    try {
      const response = await fetch(
        `${API_BASE_URLS.recommendations}/rank-based?count=${count}&min_interactions=${minInteractions}`
      );
      return await response.json();
    } catch (error) {
      console.error('Error getting rank-based recommendations:', error);
      return { status: 'error', message: error.message };
    }
  }

  async getHybridRecommendations(userIndex, count = 5) {
    try {
      const response = await fetch(
        `${API_BASE_URLS.recommendations}/hybrid/${userIndex}?count=${count}`
      );
      return await response.json();
    } catch (error) {
      console.error('Error getting hybrid recommendations:', error);
      return { status: 'error', message: error.message };
    }
  }

  async getSimilarUsers(userIndex, count = 10) {
    try {
      const response = await fetch(
        `${API_BASE_URLS.recommendations}/similar-users/${userIndex}?count=${count}`
      );
      return await response.json();
    } catch (error) {
      console.error('Error getting similar users:', error);
      return { status: 'error', message: error.message };
    }
  }

  async getRecommendationStats() {
    try {
      const response = await fetch(`${API_BASE_URLS.recommendations}/stats`);
      return await response.json();
    } catch (error) {
      console.error('Error getting recommendation stats:', error);
      return { status: 'error', message: error.message };
    }
  }

  // Vision Detection Service Methods
  async loadVisionModel() {
    try {
      const response = await fetch(`${API_BASE_URLS.vision}/load`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();
      if (data.status === 'success') {
        this.visionModelLoaded = true;
      }
      return data;
    } catch (error) {
      console.error('Error loading vision model:', error);
      return { status: 'error', message: error.message };
    }
  }

  async detectObjects(imageBase64, confidenceThreshold = 0.5) {
    try {
      const response = await fetch(`${API_BASE_URLS.vision}/detect`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: imageBase64,
          confidence_threshold: confidenceThreshold
        })
      });
      return await response.json();
    } catch (error) {
      console.error('Error detecting objects:', error);
      return { status: 'error', message: error.message };
    }
  }

  async detectObjectsFromFile(filePath) {
    try {
      const response = await fetch(`${API_BASE_URLS.vision}/detect-file`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file_path: filePath })
      });
      return await response.json();
    } catch (error) {
      console.error('Error detecting objects from file:', error);
      return { status: 'error', message: error.message };
    }
  }

  async batchDetectObjects(filePaths) {
    try {
      const response = await fetch(`${API_BASE_URLS.vision}/batch-detect`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file_paths: filePaths })
      });
      return await response.json();
    } catch (error) {
      console.error('Error batch detecting objects:', error);
      return { status: 'error', message: error.message };
    }
  }

  async getVisionStats() {
    try {
      const response = await fetch(`${API_BASE_URLS.vision}/stats`);
      return await response.json();
    } catch (error) {
      console.error('Error getting vision stats:', error);
      return { status: 'error', message: error.message };
    }
  }

  async getSupportedClasses() {
    try {
      const response = await fetch(`${API_BASE_URLS.vision}/classes`);
      return await response.json();
    } catch (error) {
      console.error('Error getting supported classes:', error);
      return { status: 'error', message: error.message };
    }
  }

  // Utility Methods
  async initializeServices() {
    const results = await Promise.allSettled([
      this.loadRecommendationModels(),
      this.loadVisionModel()
    ]);

    return {
      recommendations: results[0].status === 'fulfilled' ? results[0].value : null,
      vision: results[1].status === 'fulfilled' ? results[1].value : null
    };
  }

  convertImageToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async uploadAndDetect(file, confidenceThreshold = 0.5) {
    try {
      const base64 = await this.convertImageToBase64(file);
      return await this.detectObjects(base64, confidenceThreshold);
    } catch (error) {
      console.error('Error uploading and detecting:', error);
      return { status: 'error', message: error.message };
    }
  }
}

// Create singleton instance
const mlService = new MLService();

export default mlService;

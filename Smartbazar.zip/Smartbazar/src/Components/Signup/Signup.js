import React, { useState } from "react";
import { Link } from "react-router-dom";
import Logo from "../../olx-logo.png";
import "./Signup.css";
import { auth, db, storage } from "../../firebase/config";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { useHistory } from "react-router-dom";
import SignUpLoading from "../Loading/SignUpLoading";
import Header from "../Header/Header";

export default function Signup() {
  const history = useHistory();
  let [name, setName] = useState("");
  let [email, setEmail] = useState("");
  let [phone, setPhone] = useState("");
  let [password, setPassword] = useState("");
  let [idCard, setIdCard] = useState(null);
  let [loading, setLoading] = useState(false);
  let [showModal, setShowModal] = useState(false);

  const handleIdCardUpload = (e) => {
    e.preventDefault();
    setShowModal(true);
  };

  const handleFileChange = (e) => {
    if (e.target.files[0]) {
      setIdCard(e.target.files[0]);
    }
  };

  const handleModalConfirm = () => {
    setShowModal(false);
    // Trigger file input click after user agrees
    setTimeout(() => {
      document.getElementById('idCardInput').click();
    }, 100);
  };

  const handleModalCancel = () => {
    setShowModal(false);
    // Redirect to homepage when user cancels
    history.push('/');
  };

  const uploadIdCard = async () => {
    if (!idCard) return "";

    const storageRef = ref(storage, `idCards/${auth.currentUser.uid}/${Date.now()}_${idCard.name}`);
    await uploadBytes(storageRef, idCard);
    const downloadURL = await getDownloadURL(storageRef);
    return downloadURL;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Create user with email and password
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      // Update user profile
      await updateProfile(user, { displayName: name });
      
      // Upload ID card if provided
      let idCardDownloadUrl = "";
      if (idCard) {
        idCardDownloadUrl = await uploadIdCard();
      }
      
      // Add user data to Firestore
      await setDoc(doc(db, "users", user.uid), {
        id: user.uid,
        name: name,
        phone: phone,
        email: email,
        idCardUrl: idCardDownloadUrl,
        idCardVerified: !!idCardDownloadUrl,
        createdAt: new Date()
      });
      
      // Redirect to login page
      history.push("/login");
    } catch (error) {
      console.error("Error during signup: ", error);
      setLoading(false);
      // You might want to show an error message to the user here
    }
  };
  return (<>
    {loading && <SignUpLoading/> }
    <Header />
    <div>
      <div className="signupParentDiv">
        <img width="200px" height="200px" src={Logo} alt=""></img>
        <form onSubmit={handleSubmit}>
          <label>Full Name</label>
          <br />
          <input
            className="input"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            name="name"
            required
          />
          <br />
          <label>Email</label>
          <br />
          <input
            className="input"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            name="email"
            required
          />
          <br />
          <label>Phone</label>
          <br />
          <input
            className="input"
            type="number"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            name="phone"
            required
          />
          <br />
          <label>Password</label>
          <br />
          <input
            className="input"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            name="password"
            required
          />
          <br />
          
          {/* College ID-Card Upload Section */}
          <div className="idCardSection">
            <label>Upload College ID-Card</label>
            <br />
            <div className="idCardUploadArea" onClick={handleIdCardUpload}>
              <input
                id="idCardInput"
                type="file"
                accept="image/*,.pdf"
                onChange={handleFileChange}
                style={{ display: 'none' }}
              />
              <div className="uploadContent">
                {idCard ? (
                  <div className="uploadedFile">
                    <span className="fileName">📄 {idCard.name}</span>
                    <span className="fileSize">({(idCard.size / 1024).toFixed(2)} KB)</span>
                  </div>
                ) : (
                  <div className="uploadPlaceholder">
                    <span className="uploadIcon">📷</span>
                    <span className="uploadText">Click to upload College ID-Card</span>
                    <span className="uploadSubtext">PNG, JPG, PDF up to 10MB</span>
                  </div>
                )}
              </div>
            </div>
            {idCard && (
              <div className="fileActions">
                <button type="button" className="removeFileBtn" onClick={() => setIdCard(null)}>
                  Remove File
                </button>
              </div>
            )}
          </div>
          
          <br />
          <button type="submit">Signup</button>
        </form>
        <Link to="/login">Login</Link>
        <br />
        <button
          type="button"
          onClick={() => history.goBack()}
          style={{
            marginTop: '10px',
            backgroundColor: 'transparent',
            color: '#002f34',
            border: '1px solid #002f34',
            padding: '8px 20px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          Back
        </button>
      </div>
    </div>

    {/* Privacy Notice Modal */}
    {showModal && (
      <div className="modalOverlay">
        <div className="modalContent">
          <div className="modalHeader">
            <h3>🔒 Privacy Notice - College ID-Card Upload</h3>
          </div>
          <div className="modalBody">
            <div className="noticeIcon">⚠️</div>
            <p className="noticeText">
              <strong>Important Information:</strong> By uploading your College ID-Card, you agree to the following terms:
            </p>
            <ul className="noticeList">
              <li>If you engage in any illegal activities on this platform, your data (including ID-Card) will be shared with your college department and relevant authorities.</li>
              <li>This verification is for your safety and privacy protection.</li>
              <li>Your ID-Card information will be kept confidential and used only for verification purposes.</li>
              <li>False information or fake ID-Card uploads will result in immediate account suspension.</li>
            </ul>
            <p className="safetyMessage">
              <strong>Stay Safe - This is for your protection and privacy!</strong>
            </p>
          </div>
          <div className="modalFooter">
            <button className="cancelBtn" onClick={handleModalCancel}>
              Cancel
            </button>
            <button className="confirmBtn" onClick={handleModalConfirm}>
              I Agree & Continue
            </button>
          </div>
        </div>
      </div>
    )}
    </>
  );
}

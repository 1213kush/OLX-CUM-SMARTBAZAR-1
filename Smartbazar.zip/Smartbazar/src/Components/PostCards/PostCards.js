import React, { useContext, useState, useEffect } from 'react';
import Heart from '../../assets/Heart';
import { useHistory } from "react-router-dom";
import { PostContext } from "../../contextStore/PostContext";
import { AuthContext } from "../../contextStore/AuthContext";
import { CartContext } from "../../contextStore/CartContext";
import "./postcards.css";
import { Timestamp } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { doc, deleteDoc } from 'firebase/firestore';

function PostCards({ product, index }) {
    const { setPostContent } = useContext(PostContext);
    const { user } = useContext(AuthContext);
    const { addToCart } = useContext(CartContext);
    const [formattedDate, setFormattedDate] = useState('');
    const [loading, setLoading] = useState(false);
    const [cartLoading, setCartLoading] = useState(false);
    const history = useHistory();

    const isOwner = user && product.userId === user.uid;

    const handleDelete = async (e) => {
        e.stopPropagation();
        if (!window.confirm('Are you sure you want to delete this product?')) {
            return;
        }
        
        setLoading(true);
        try {
            await deleteDoc(doc(db, 'products', product.id));
            window.location.reload(); // Refresh to show updated list
        } catch (error) {
            console.error('Error deleting product:', error);
            alert('Error deleting product. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const handleEdit = (e) => {
        e.stopPropagation();
        history.push(`/edit/${product.id}`);
    };

    const handleAddToCart = (e) => {
        e.stopPropagation();
        setCartLoading(true);
        try {
            addToCart(product);
            alert('Product added to cart!');
        } catch (error) {
            console.error('Error adding to cart:', error);
            alert('Error adding to cart. Please try again.');
        } finally {
            setCartLoading(false);
        }
    };

    useEffect(() => {
        if (product?.createdAt) {
            let date;
            // Check if createdAt is a Firebase Timestamp
            if (product.createdAt.toDate instanceof Function) {
                date = product.createdAt.toDate();
            } else if (product.createdAt.seconds) {
                // Handle case where it's a Firestore Timestamp object
                date = new Timestamp(
                    product.createdAt.seconds,
                    product.createdAt.nanoseconds
                ).toDate();
            } else {
                date = new Date(product.createdAt);
            }
            
            setFormattedDate(date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
            }));
        }
        
        // Cleanup function
        return () => {
            // Any cleanup if needed
        };
    }, [product?.createdAt]);

    return (
      <div className="card" key={index} onClick={()=>{
        setPostContent(product)
        history.push("/view")
      }}>
        <div className="favorite">
          <Heart></Heart>
        </div>
        {isOwner && (
          <div className="owner-actions">
            <button 
              className="edit-btn" 
              onClick={handleEdit}
              disabled={loading}
              title="Edit product"
            >
              ✏️
            </button>
            <button 
              className="delete-btn" 
              onClick={handleDelete}
              disabled={loading}
              title="Delete product"
            >
              🗑️
            </button>
          </div>
        )}
        {!isOwner && (
          <button 
            className="add-to-cart-btn" 
            onClick={handleAddToCart}
            disabled={cartLoading}
            title="Add to cart"
          >
            {cartLoading ? 'Adding...' : '🛒 Add to Cart'}
          </button>
        )}
        <div className="image">
          <img src={product.images && product.images.length > 0 ? product.images[0] : ''} alt={product.name} />
        </div>
        <div className="content">
          <p className="rate">&#x20B9; {product.price}</p>
          <span className="category"> {product.category} </span>
          <p className="name"> {product.name}</p>
        </div>
        <div className="date">
          <span>{formattedDate || 'Date not available'}</span>
        </div>
      </div>
       
    )
}

export default PostCards

import React, { useState } from "react";
import { Link } from "react-router-dom";
import {useHistory} from "react-router-dom";
import { auth } from "../../firebase/config";
import { signInWithEmailAndPassword } from "firebase/auth";
import Logo from "../../olx-logo.png";
import RoundLoading from "../Loading/RoundLoading";
import Header from "../Header/Header";
import "./Login.css";

function Login() {
  let [email, setEmail] = useState("");
  let [password, setPassword] = useState("");
  let [loading,setLoading]=useState(false)
  const history = useHistory()
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      await signInWithEmailAndPassword(auth, email, password);
      history.push("/");
    } catch (error) {
      console.error("Login error: ", error);
      alert(error.message);
    } finally {
      setLoading(false);
    }

  };
  return (<>
    {loading && <RoundLoading/> }
    <Header />
    <div>
      <div className="loginParentDiv">
        <img width="200px" height="200px" src={Logo} alt=""></img>
        <form onSubmit={handleSubmit}>
          <label>Email</label>
          <br />
          <input
            className="input"
            type="email"
            placeholder="ankush@gmail.com"
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <br />
          <label>Password</label>
          <br />
          <input
            className="input"
            type="password"
            name="password"
            placeholder="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <br />
          <br />
          <button>Login</button>
        </form>
        <Link to="/signup">Signup</Link>
        <br />
        <button
          type="button"
          onClick={() => history.goBack()}
          style={{
            marginTop: '10px',
            backgroundColor: 'transparent',
            color: '#002f34',
            border: '1px solid #002f34',
            padding: '8px 20px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          Back
        </button>
      </div> 
    </div>
    </>
  );
}

export default Login;

import React, { useState } from "react";
import DynamicPosts from "../DynamicPosts/DynamicPosts";
import { useHistory } from "react-router";
import "./Banner.css";

function Banner() {
  let [category, setCategory] = useState();
  const history = useHistory();

  const handleBuyClick = () => {
    history.push("/");
  };

  const handleSellClick = () => {
    history.push("/create");
  };

  const handleExchangeClick = () => {
    history.push("/myproducts");
  };
  
  return (
    <div className="bannerParentDiv">
      <div className="bannerChildDiv">
        <div className="menuBar">
          <div className="categoryMenu">
            <select
              name="Category"
              onChange={(e) => {
                setCategory(e.target.value);
              }}
            >
              {" "}
              <option value="null">ALL CATEGORIES</option>
              <optgroup label="Vehicles">
                <option value="Cars">Cars</option>
                <option value="Bikes">Bikes</option>
                <option value="Motorcycles">Motorcycles</option>
                <option value="Scooters">Scooters</option>
                <option value="Spare Parts">Spare Parts</option>
                <option value="Bicycles">Bicycles</option>
              </optgroup>
              <optgroup label="Properties">
            
                <option value="For Rent: Shops & Offices">For Rent: Shops & Offices</option>
                <option value="For Sale: Shops & Offices">For Sale: Shops & Offices</option>
                <option value="PG & Guest Houses">PG & Guest Houses</option>
              </optgroup>
              <optgroup label="Electronics & Appliances">
                <option value="TVs, Video - Audio">TVs, Video - Audio</option>
                <option value="Kitchen & Other Appliances">Kitchen & Other Appliances</option>
                <option value="Computers & Laptops">Computers & Laptops</option>
                <option value="Cameras & Lenses">Cameras & Lenses</option>
                <option value="Games & Entertainment">Games & Entertainment</option>
                <option value="Fridges">Fridges</option>
                <option value="Computer Accessories">Computer Accessories</option>
                <option value="Hard Disks, Printers & Monitors">Hard Disks, Printers & Monitors</option>
                <option value="ACs">ACs</option>
                <option value="Washing Machines">Washing Machines</option>
              </optgroup>
              <optgroup label="Mobiles">
                <option value="Mobile Phones">Mobile Phones</option>
                <option value="Accessories">Accessories</option>
                <option value="Tablets">Tablets</option>
              </optgroup>
              <optgroup label="Commercial Vehicles & Spares">
                <option value="Commercial & Other Vehicles">Commercial & Other Vehicles</option>
                <option value="Spare Parts">Spare Parts</option>
              </optgroup>

              <optgroup label="Furniture">
                <option value="Sofa & Dining">Sofa & Dining</option>
                <option value="Beds & Wardrobes">Beds & Wardrobes</option>
                <option value="Home Decor & Garden">Home Decor & Garden</option>
                <option value="Kids Furniture">Kids Furniture</option>
                <option value="Other Household Items">Other Household Items</option>
              </optgroup>
              <optgroup label="Fashion">
                <option value="Men">Men</option>
                <option value="Women">Women</option>
                
              </optgroup>
              
              <optgroup label="Books, Sports & Hobbies">
                <option value="Books">Books</option>
                <option value="Gym & Fitness">Gym & Fitness</option>
                <option value="Musical Instruments">Musical Instruments</option>
                <option value="Sports Equipment">Sports Equipment</option>
                <option value="Other Hobbies">Other Hobbies</option>
              </optgroup>
              <optgroup label="Services">
                <option value="Education & Classes">Education & Classes</option>
                <option value = "solved Previous year papers">solved Previous year papers</option>
                <option value = "hand written Notes">hand written Notes</option>
                <option value = "Question Papers">Question Papers</option>
                <option value = "Mock Tests">Mock Tests</option>
                <option value = "Study Material">Study Material</option>
                <option value = "Books">Books</option>
                <option value = "Other">Other</option>

              
              </optgroup>
            </select>
          </div>
          <div className="otherQuickOptions">
            <span onClick={()=>setCategory("Cars")}>Cars</span>
            <span onClick={()=>setCategory("Motorcycles")}>Bikes</span>
            <span onClick={()=>setCategory("Mobile Phones")}>Mobiles</span>
            <span onClick={()=>setCategory("For Sale: Houses & Apartments")}>Properties</span>
            <span onClick={()=>setCategory("TVs, Video - Audio")}>Electronics</span>
            <span onClick={()=>setCategory("Furniture")}>Furniture</span>
            <span onClick={()=>setCategory("Jobs")}>Jobs</span>
            <span onClick={()=>setCategory("Books")}>Books & Hobbies</span>
            <span onClick={()=>setCategory("Fashion")}>Fashion</span>
            
          </div>
        </div>
        
        {/* New Improved Banner Design */}
        <div className="hero-banner">
          <div className="banner-content">
            <div className="banner-text">
              <h1 className="main-headline">SMARTBAZAR</h1>
              <p className="sub-headline">Your Campus Marketplace</p>
              <div className="action-buttons">
                <div className="action-item" onClick={handleBuyClick}>
                  <span className="action-text">BUY</span>
                </div>
                <div className="action-item" onClick={handleSellClick}>
                  <span className="action-text">SELL</span>
                </div>
                <div className="action-item" onClick={handleExchangeClick}>
                  <span className="action-text">EXCHANGE</span>
                </div>
              </div>
              
              {/* Value Proposition Taglines */}
              <div className="value-propositions">
                <div className="value-item">
                  <span className="value-icon">💰</span>
                  <span className="value-text">Save Money</span>
                </div>
                <div className="value-item">
                  <span className="value-icon">⚡</span>
                  <span className="value-text">Sell in Minutes</span>
                </div>
                <div className="value-item">
                  <span className="value-icon">✅</span>
                  <span className="value-text">Verified Campus Buyers</span>
                </div>
                <div className="value-item">
                  <span className="value-icon">🚀</span>
                  <span className="value-text">Fast Exchange Deals</span>
                </div>
              </div>
            </div>
            
            {/* Campus Illustrations */}
            <div className="banner-illustrations">
              <div className="campus-elements">
                <div className="campus-icon hostel">
                  <span>🏫</span>
                  <span className="icon-label">Hostels</span>
                </div>
                <div className="campus-icon students">
                  <span>👥</span>
                  <span className="icon-label">Students</span>
                </div>
                <div className="campus-icon campus">
                  <span>🎓</span>
                  <span className="icon-label">Campus</span>
                </div>
              </div>
              
              {/* Phone Mockups */}
              <div className="phone-mockups">
                <div className="phone-mockup">
                  <div className="phone-frame">
                    <div className="phone-screen">
                      <div className="app-header">SmartBazar</div>
                      <div className="app-content">
                        <div className="product-card">
                          <div className="product-image"></div>
                          <div className="product-info">
                            <div className="product-title">Textbook</div>
                            <div className="product-price">₹299</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="phone-mockup">
                  <div className="phone-frame">
                    <div className="phone-screen">
                      <div className="app-header">Sell Item</div>
                      <div className="app-content">
                        <div className="upload-area">📷</div>
                        <div className="form-field">Title</div>
                        <div className="form-field">Price</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
     { category!=null && <DynamicPosts category={category}/>  }
    </div>
  );
}

export default Banner;

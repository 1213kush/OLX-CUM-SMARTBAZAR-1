import React, { useContext, useEffect, useState } from "react";
import { PostContext } from "../../contextStore/PostContext";
import { AuthContext } from "../../contextStore/AuthContext";
import { db } from "../../firebase/config";
import { collection, query, where, getDocs } from "firebase/firestore";
import { useHistory } from "react-router";
import { Timestamp } from 'firebase/firestore';
import "./View.css";
function View() {
  let { postContent } = useContext(PostContext);
  const { user } = useContext(AuthContext);
  const [userDetails, setUserDetails] = useState();
  const [formattedDate, setFormattedDate] = useState('');
  const history = useHistory();

  useEffect(() => {
    // Format the date
    if (postContent?.createdAt) {
      let date;
      if (postContent.createdAt.toDate instanceof Function) {
        date = postContent.createdAt.toDate();
      } else if (postContent.createdAt.seconds) {
        date = new Timestamp(
          postContent.createdAt.seconds,
          postContent.createdAt.nanoseconds
        ).toDate();
      } else {
        date = new Date(postContent.createdAt);
      }
      
      setFormattedDate(date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }));
    }
  }, [postContent?.createdAt]);
  useEffect(() => {
    const fetchUserDetails = async () => {
      let { userId } = postContent;
      if (userId === undefined) {
        history.push("/");
        return;
      }

      try {
        const usersRef = collection(db, "users");
        const q = query(usersRef, where("id", "==", userId));
        const querySnapshot = await getDocs(q);
        
        querySnapshot.forEach((doc) => {
          setUserDetails(doc.data());
        });
      } catch (error) {
        console.error("Error fetching user details: ", error);
      }
    };

    fetchUserDetails();
  }, [history, postContent]);

  const handleSendMessage = () => {
    if (!user) {
      history.push('/login');
      return;
    }

    if (user.uid === postContent.userId) {
      alert('You cannot send a message to yourself about your own product!');
      return;
    }

    const buyerName = user.displayName || user.email || 'Anonymous';
    
    // Check seller's contact preference
    if (postContent.contactPreference === 'phone' && postContent.phoneNumber) {
      // Handle phone/WhatsApp contact
      const message = `Hi! I'm interested in your product "${postContent.name}" priced at ₹${postContent.price}. Listed on SmartBazar. - ${buyerName}`;
      
      if (postContent.showWhatsApp) {
        // Open WhatsApp
        const whatsappUrl = `https://wa.me/91${postContent.phoneNumber}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
      } else {
        // Open phone dialer
        window.location.href = `tel:+91${postContent.phoneNumber}`;
        alert(`Calling ${postContent.phoneNumber}... You can mention: "${message}"`);
      }
    } else if (postContent.contactPreference === 'email' || !postContent.contactPreference) {
      // Handle email contact (default)
      const sellerEmail = postContent.contactEmail || userDetails?.email;
      
      if (!sellerEmail) {
        alert('Seller email is not available. Please try again later.');
        return;
      }

      const subject = `Inquiry about: ${postContent.name} - SmartBazar`;
      
      const body = `Hi ${userDetails.name},

I'm interested in your product "${postContent.name}" listed on SmartBazar.

Product Details:
• Price: ₹${postContent.price}
• Category: ${postContent.category}
• Posted: ${formattedDate || 'Recently'}

${postContent.description ? `Description: ${postContent.description}` : ''}

Could you please let me know if this item is still available?

Thank you!
${buyerName}
${user.email || 'No email provided'}
Sent via SmartBazar`;

      const mailtoLink = `mailto:${sellerEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      
      window.location.href = mailtoLink;
    } else {
      alert('Seller has not provided contact information. Please try again later.');
    }
  };
  return (
    <div className="viewParentDiv">
      <div className="imageShowDiv">
        <img src={postContent.images && postContent.images.length > 0 ? postContent.images[0] : ''} alt={postContent.name} />
      </div>{" "}
      <div className="rightSection">
        <div className="productDetails">
          <p>&#x20B9; {postContent.price} </p>
          <span>{postContent.name}</span>
          <p>{postContent.category}</p>
          <span>{formattedDate || 'Date not available'}</span>
        </div>
        <div className="productDescription">
            <p className="p-bold">Product Description</p>
            <p>{postContent.description}</p>
            
          </div>
        {userDetails &&
          <div className="contactDetails">
            <p className="p-bold">Seller details</p>
            <p>Name : {userDetails.name}</p>
            <button 
              className={`sendMessageBtn ${postContent.contactPreference === 'phone' && postContent.showWhatsApp ? 'whatsapp' : postContent.contactPreference === 'phone' ? 'phone' : 'email'}`} 
              onClick={handleSendMessage}
            >
              {postContent.contactPreference === 'phone' && postContent.showWhatsApp ? 'Message on WhatsApp' :
               postContent.contactPreference === 'phone' ? 'Call Seller' : 'Send Message'}
            </button>
          </div>
        }
       
      </div>
    </div>
  );
}
export default View;

import React, { useState, useRef, useCallback } from 'react';
import './VisionDetection.css';
import mlService from '../../Services/MLService';

const VisionDetection = ({ onDetectionComplete }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [detecting, setDetecting] = useState(false);
  const [detectionResult, setDetectionResult] = useState(null);
  const [error, setError] = useState(null);
  const [confidenceThreshold, setConfidenceThreshold] = useState(0.5);
  const [supportedClasses, setSupportedClasses] = useState([]);
  const fileInputRef = useRef(null);

  const loadSupportedClasses = useCallback(async () => {
    try {
      const result = await mlService.getSupportedClasses();
      if (result.status === 'success') {
        setSupportedClasses(result.supported_classes || []);
      }
    } catch (err) {
      console.error('Error loading supported classes:', err);
    }
  }, []);

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        setError('Please select an image file');
        return;
      }

      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        setError('File size must be less than 10MB');
        return;
      }

      setSelectedFile(file);
      setError(null);
      setDetectionResult(null);

      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewUrl(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDragOver = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleDragLeave = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleDrop = (event) => {
    event.preventDefault();
    event.stopPropagation();

    const files = event.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      const fakeEvent = { target: { files: [file] } };
      handleFileSelect(fakeEvent);
    }
  };

  const handleDetectObjects = async () => {
    if (!selectedFile) {
      setError('Please select an image first');
      return;
    }

    setDetecting(true);
    setError(null);
    setDetectionResult(null);

    try {
      const result = await mlService.uploadAndDetect(selectedFile, confidenceThreshold);
      
      if (result.status === 'success') {
        setDetectionResult(result);
        if (onDetectionComplete) {
          onDetectionComplete(result);
        }
      } else {
        setError(result.message || 'Detection failed');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setDetecting(false);
    }
  };

  const handleReset = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setDetectionResult(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getClassColor = (className) => {
    const colors = {
      'cart': '#cc6633',
      'electronics': '#1231dc',
      'furniture': '#0099ff',
      'mattress': '#189610',
      'sofa': '#afaff6',
      'trash_bags': '#ac3e3b',
      'trash': '#c69900'
    };
    return colors[className] || '#666666';
  };

  const formatConfidence = (confidence) => {
    return `${(confidence * 100).toFixed(1)}%`;
  };

  return (
    <div className="vision-detection">
      <div className="detection-header">
        <h3>Vision Detection</h3>
        <div className="confidence-control">
          <label htmlFor="confidence">Confidence: {formatConfidence(confidenceThreshold)}</label>
          <input
            id="confidence"
            type="range"
            min="0.1"
            max="0.9"
            step="0.1"
            value={confidenceThreshold}
            onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
            disabled={detecting}
          />
        </div>
      </div>

      <div className="upload-area">
        <div
          className={`drop-zone ${selectedFile ? 'has-file' : ''}`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          {previewUrl ? (
            <div className="preview-container">
              <img src={previewUrl} alt="Preview" className="preview-image" />
              <div className="preview-overlay">
                <button className="change-btn" onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}>
                  Change Image
                </button>
              </div>
            </div>
          ) : (
            <div className="upload-prompt">
              <div className="upload-icon">📷</div>
              <p>Click to upload or drag and drop</p>
              <p className="upload-hint">PNG, JPG, JPEG up to 10MB</p>
            </div>
          )}
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          style={{ display: 'none' }}
        />
      </div>

      {error && (
        <div className="error-message">
          <p>{error}</p>
        </div>
      )}

      <div className="action-buttons">
        <button
          className="detect-btn"
          onClick={handleDetectObjects}
          disabled={!selectedFile || detecting}
        >
          {detecting ? (
            <>
              <div className="btn-spinner"></div>
              Detecting...
            </>
          ) : (
            'Detect Objects'
          )}
        </button>
        <button
          className="reset-btn"
          onClick={handleReset}
          disabled={detecting}
        >
          Reset
        </button>
      </div>

      {detectionResult && detectionResult.success && (
        <div className="detection-results">
          <h4>Detection Results</h4>
          
          <div className="results-grid">
            <div className="annotated-image">
              <h5>Annotated Image</h5>
              <img 
                src={detectionResult.annotated_image} 
                alt="Annotated detection" 
                className="result-image"
              />
            </div>
            
            <div className="detection-info">
              <h5>Detections ({detectionResult.detection_count})</h5>
              
              {detectionResult.detections.length > 0 ? (
                <div className="detections-list">
                  {detectionResult.detections.map((detection, index) => (
                    <div key={index} className="detection-item">
                      <div 
                        className="class-indicator"
                        style={{ backgroundColor: getClassColor(detection.class) }}
                      ></div>
                      <div className="detection-details">
                        <span className="class-name">{detection.class}</span>
                        <span className="confidence">{formatConfidence(detection.confidence)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="no-detections">No objects detected</p>
              )}
              
              <div className="detection-summary">
                <div className="summary-item">
                  <label>Total Detections:</label>
                  <span>{detectionResult.detection_count}</span>
                </div>
                <div className="summary-item">
                  <label>Confidence Threshold:</label>
                  <span>{formatConfidence(confidenceThreshold)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {supportedClasses.length > 0 && (
        <div className="supported-classes">
          <h5>Supported Classes</h5>
          <div className="classes-grid">
            {supportedClasses.map((className) => (
              <div key={className} className="class-badge">
                <div 
                  className="class-color"
                  style={{ backgroundColor: getClassColor(className) }}
                ></div>
                <span>{className}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VisionDetection;

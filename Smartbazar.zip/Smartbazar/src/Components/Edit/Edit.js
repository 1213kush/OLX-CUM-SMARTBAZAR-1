import React, { Fragment, useState, useContext, useEffect } from "react";
import "./Edit.css";
import Header from "../Header/Header";
import { db, storage } from "../../firebase/config";
import { ref, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage";
import { doc, updateDoc, getDoc } from "firebase/firestore";
import { AuthContext } from "../../contextStore/AuthContext";
import { useHistory, useParams } from "react-router";
import GoLoading from "../Loading/GoLoading";

const Edit = () => {
  const { user } = useContext(AuthContext);
    const history = useHistory();
  const { id } = useParams();
  
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [images, setImages] = useState([]);
  const [existingImages, setExistingImages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [fetchLoading, setFetchLoading] = useState(true);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!user || !id) {
        history.push("/");
        return;
      }

      try {
        const productDoc = await getDoc(doc(db, "products", id));
        
        if (!productDoc.exists()) {
          setError("Product not found");
          history.push("/");
          return;
        }

        const productData = productDoc.data();
        
        // Check if user is the owner
        if (productData.userId !== user.uid) {
          setError("You are not authorized to edit this product");
          history.push("/");
          return;
        }

        // Set form data
        setName(productData.name || "");
        setCategory(productData.category || "");
        setPrice(productData.price || "");
        setDescription(productData.description || "");
        setExistingImages(productData.images || []);
        
      } catch (error) {
        console.error("Error fetching product:", error);
        setError("Error fetching product details");
        history.push("/");
      } finally {
        setFetchLoading(false);
      }
    };

    fetchProduct();
  }, [user, id, history]);

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    
    // Check if total images won't exceed 6
    if (images.length + existingImages.length + files.length > 6) {
      setError(`You can have a maximum of 6 images. Currently: ${existingImages.length + images.length}/6`);
      return;
    }
    
    // Filter only image files
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length === 0) {
      setError("Please select valid image files");
      return;
    }
    
    setImages(prevImages => [...prevImages, ...imageFiles]);
    setError("");
  };

  const removeNewImage = (index) => {
    setImages(prevImages => prevImages.filter((_, i) => i !== index));
  };

  const removeExistingImage = async (index) => {
    const imageToRemove = existingImages[index];
    
    try {
      // Delete from Firebase Storage
      const storageRef = ref(storage, imageToRemove);
      await deleteObject(storageRef);
      
      // Remove from state
      setExistingImages(prevImages => prevImages.filter((_, i) => i !== index));
      setError("");
    } catch (error) {
      console.error("Error removing image:", error);
      setError("Error removing image. Please try again.");
    }
  };

  const handleSubmit = async () => {
    if (!user) {
      setError("You must be logged in to update a listing");
      return;
    }

    const totalImages = images.length + existingImages.length;
    
    if (totalImages < 1) {
      setError("Please have at least 1 image (maximum 6)");
      return;
    }
    
    if (totalImages > 6) {
      setError("You can have a maximum of 6 images");
      return;
    }

    if (!name || !category || !price || !description) {
      setError("Please fill in all required fields");
      return;
    }

    setLoading(true);
    setError("");
    
    try {
      console.log("Starting update process...");
      
      // Upload new images and get their URLs
      const newImageUrls = [];
      
      for (let i = 0; i < images.length; i++) {
        const image = images[i];
        console.log(`Uploading image ${i + 1}/${images.length}:`, image.name);
        
        try {
          // Create a unique filename with user ID and timestamp
          const imageName = `${user.uid}_${Date.now()}_${image.name}`;
          const storageRef = ref(storage, `images/${imageName}`);
          
          console.log("Storage ref created:", storageRef);
          
          // Upload the file
          console.log("Starting upload...");
          const snapshot = await uploadBytes(storageRef, image);
          console.log("Upload complete:", snapshot);
          
          // Get the download URL
          console.log("Getting download URL...");
          const url = await getDownloadURL(snapshot.ref);
          console.log("Download URL obtained:", url);
          newImageUrls.push(url);
          
          // Small delay between uploads to prevent rate limiting
          await new Promise(resolve => setTimeout(resolve, 500));
        } catch (uploadError) {
          console.error("Error uploading image:", uploadError);
          throw new Error(`Failed to upload ${image.name}. ${uploadError.message}`);
        }
      }
      
      // Combine existing and new image URLs
      const allImageUrls = [...existingImages, ...newImageUrls];
      
      console.log("All images ready. URLs:", allImageUrls);
      
      // Update product in Firestore
      console.log("Updating product in Firestore...");
      await updateDoc(doc(db, "products", id), {
        name,
        category,
        price: Number(price),
        description,
        images: allImageUrls,
        updatedAt: new Date(),
      });
      
      console.log("Product updated successfully");
      
      // Redirect to home page
      history.push("/");
    } catch (error) {
      console.error("Error updating product:", error);
      setError(error.message || "Error updating product. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (fetchLoading) {
    return (
      <Fragment>
        <Header />
        <div style={{ padding: '40px 20px', maxWidth: '900px', margin: '0 auto' }}>
          <GoLoading />
        </div>
      </Fragment>
    );
  }

  return (
    <Fragment>
      <Header />
      {loading && <GoLoading/>}
      <div className="centerDiv">
        <h1 className="create-title">Edit Listing</h1>
        <p className="create-subtitle">Update your product details to keep buyers informed.</p>

        <label>Name</label>
        <input
          className="input"
          type="text"
          name="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <label>Category</label>
        <select
          name="Category"
          onChange={(e) => setCategory(e.target.value)}
          className="input"
          value={category}
        >
          <option value="">Select Category</option>
          
          <optgroup label="Vehicles">
            <option value="Cars">Cars</option>
            <option value="Bikes">Bikes</option>
            <option value="Motorcycles">Motorcycles</option>
            <option value="Scooters">Scooters</option>
            <option value="Spare Parts">Spare Parts</option>
            <option value="Bicycles">Bicycles</option>
          </optgroup>
          
          <optgroup label="Properties">
            <option value="For Rent: Shops & Offices">For Rent: Shops & Offices</option>
            <option value="For Sale: Shops & Offices">For Sale: Shops & Offices</option>
            <option value="PG & Guest Houses">PG & Guest Houses</option>
          </optgroup>
          
          <optgroup label="Electronics & Appliances">
            <option value="TVs, Video - Audio">TVs, Video - Audio</option>
            <option value="Kitchen & Other Appliances">Kitchen & Other Appliances</option>
            <option value="Computers & Laptops">Computers & Laptops</option>
            <option value="Cameras & Lenses">Cameras & Lenses</option>
            <option value="Games & Entertainment">Games & Entertainment</option>
            <option value="Fridges">Fridges</option>
            <option value="Computer Accessories">Computer Accessories</option>
            <option value="Hard Disks, Printers & Monitors">Hard Disks, Printers & Monitors</option>
            <option value="ACs">ACs</option>
            <option value="Washing Machines">Washing Machines</option>
          </optgroup>
          
          <optgroup label="Mobiles">
            <option value="Mobile Phones">Mobile Phones</option>
            <option value="Accessories">Accessories</option>
            <option value="Tablets">Tablets</option>
          </optgroup>
          
          <optgroup label="Commercial Vehicles & Spares">
            <option value="Commercial & Other Vehicles">Commercial & Other Vehicles</option>
            <option value="Spare Parts">Spare Parts</option>
          </optgroup>
          
          <optgroup label="Furniture">
            <option value="Sofa & Dining">Sofa & Dining</option>
            <option value="Beds & Wardrobes">Beds & Wardrobes</option>
            <option value="Home Decor & Garden">Home Decor & Garden</option>
            <option value="Kids Furniture">Kids Furniture</option>
            <option value="Other Household Items">Other Household Items</option>
          </optgroup>
          
          <optgroup label="Fashion">
            <option value="Men">Men</option>
            <option value="Women">Women</option>
          </optgroup>
          
          <optgroup label="Books, Sports & Hobbies">
            <option value="Books">Books</option>
            <option value="Gym & Fitness">Gym & Fitness</option>
            <option value="Musical Instruments">Musical Instruments</option>
            <option value="Sports Equipment">Sports Equipment</option>
            <option value="Other Hobbies">Other Hobbies</option>
          </optgroup>
          
          <optgroup label="Services">
            <option value="Education & Classes">Education & Classes</option>
            <option value="solved Previous year papers">solved Previous year papers</option>
            <option value="hand written Notes">hand written Notes</option>
            <option value="Question Papers">Question Papers</option>
            <option value="Mock Tests">Mock Tests</option>
            <option value="Study Material">Study Material</option>
            <option value="Books">Books</option>
            <option value="Other">Other</option>
          </optgroup>
        </select>

        <label>Price (₹)</label>
        <input
          className="input"
          type="number"
          name="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />

        <label>Description</label>
        <textarea
          className="input"
          name="Description"
          rows="3"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <div className="image-upload-section">
          <label>Product Images ({existingImages.length + images.length}/6)</label>
          
          {/* Existing Images */}
          {existingImages.length > 0 && (
            <div className="image-preview-container">
              {existingImages.map((image, index) => (
                <div key={`existing-${index}`} className="image-preview-item">
                  <img
                    alt={`Existing ${index + 1}`}
                    src={image}
                    className="preview-image"
                  />
                  <button 
                    type="button" 
                    className="remove-image-btn"
                    onClick={() => removeExistingImage(index)}
                    aria-label="Remove existing image"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* New Images */}
          {images.length > 0 && (
            <div className="image-preview-container">
              {images.map((image, index) => (
                <div key={`new-${index}`} className="image-preview-item">
                  <img
                    alt={`New ${index + 1}`}
                    src={URL.createObjectURL(image)}
                    className="preview-image"
                  />
                  <button 
                    type="button" 
                    className="remove-image-btn"
                    onClick={() => removeNewImage(index)}
                    aria-label="Remove new image"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
          
          <div className="file-upload-wrapper">
            <label className="file-upload-label">
              <span>+ Add Images</span>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageChange}
                className="file-upload-input"
                disabled={existingImages.length + images.length >= 6}
              />
            </label>
            <div className="image-count">
              {existingImages.length + images.length} / 6 images
            </div>
          </div>
          
          {error && <div className="error-message">{error}</div>}
        </div>

        <div className="button-group">
          <button className="cancelBtn" onClick={() => history.push("/")}>
            Cancel
          </button>
          <button className="uploadBtn" onClick={handleSubmit}>
            Update Listing
          </button>
        </div>
      </div> 
    </Fragment>
  );
};

export default Edit;

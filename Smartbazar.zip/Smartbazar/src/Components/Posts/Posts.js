import React, { useState, useEffect, useContext } from "react";
import { Link } from "react-router-dom";

import "./Post.css";
import { db } from "../../firebase/config";
import { collection, getDocs, orderBy, query } from "firebase/firestore";
import BarLoading from "../Loading/BarLoading";
import PostCards from "../PostCards/PostCards";

import { AllPostContext } from "../../contextStore/AllPostContext";

function Posts() {
  const { setAllPost } = useContext(AllPostContext);
  let [posts, setPosts] = useState([]); //for showing all posts in Descending order of date
  let [posts2, setPosts2] = useState([]); //for showing all posts in Ascending order of date
  let [loading, setLoading] = useState(false);
  let [loading2,setLoading2] = useState(false)
  useEffect(() => {
    let isMounted = true;

    const fetchPosts = async () => {
      setLoading(true);
      setLoading2(true);
      
      try {
        // Fetch posts in descending order
        const qDesc = query(collection(db, "products"), orderBy("createdAt", "desc"));
        const querySnapshotDesc = await getDocs(qDesc);
        
        if (!isMounted) return;
        
        const allPostsDescendingOrder = querySnapshotDesc.docs.map((doc) => ({
          ...doc.data(),
          id: doc.id,
        }));
        
        setPosts2(allPostsDescendingOrder);
        setAllPost(allPostsDescendingOrder);
        setLoading(false);

        // Only fetch ascending order if component is still mounted
        if (!isMounted) return;
        
        // Fetch posts in ascending order
        const qAsc = query(collection(db, "products"), orderBy("createdAt", "asc"));
        const querySnapshotAsc = await getDocs(qAsc);
        
        if (!isMounted) return;
        
        const allPostsAscendingOrder = querySnapshotAsc.docs.map((doc) => ({
          ...doc.data(),
          id: doc.id,
        }));
        
        setPosts(allPostsAscendingOrder);
        setLoading2(false);
      } catch (error) {
        if (isMounted) {
          console.error("Error fetching posts: ", error);
          setLoading(false);
          setLoading2(false);
        }
      }
    };

    fetchPosts();

    // Cleanup function
    return () => {
      isMounted = false;
    };
  }, [setAllPost]);
  // quickMenuCards assign all cards of post item later it will be displayed
  let quickMenuCards = posts.map((product, index) => {
    return(<div className="quick-menu-cards" key={index}> <PostCards product={product} index={index} /> </div>);
  });

  let freshRecomendationCards = posts2.map((product, index) => { if(index<4) {
    return (<div className="fresh-recomendation-card" key={index}> <PostCards product={product} index={index} /> </div>);}
    return null 
});
  return (
    <div className="postParentDiv">
      {posts && (
        <div className="moreView">
          <div className="heading">
            <span>Quick Menu</span>
            <Link to="./viewmore">
              {" "}
              <span>View more</span>{" "}
            </Link>
          </div>
          <div className="cards">
            {" "}
            {loading ? <BarLoading /> : quickMenuCards}
          </div>
        </div>
      )}
     <div className="recommendations">
        <div className="heading">
          <span>Fresh recommendations</span>
        </div>
        <div className="fresh-recomendation-cards cards">{loading2 ? <BarLoading/> : freshRecomendationCards}</div> 
      </div> 
    </div>
  );
}

export default Posts;

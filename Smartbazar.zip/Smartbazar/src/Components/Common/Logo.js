import React from 'react';
import { Link } from 'react-router-dom';
import logo from '../../assets/images/banner copy.png';

const Logo = ({ className = '', ...props }) => {
  return (
    <Link to="/" className={className} {...props}>
      <img 
        src={logo} 
        alt="SmartBazar Logo" 
        style={{ height: '40px' }} // Adjust height as needed
      />
    </Link>
  );
};

export default Logo;

import React, { useState, useEffect } from 'react';
import './RecommendationWidget.css';
import mlService from '../../Services/MLService';

const RecommendationWidget = ({ userId = 0, onProductClick }) => {
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [method, setMethod] = useState('hybrid');
  const [stats, setStats] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadRecommendations();
  }, [userId, method]);

  const loadRecommendations = async () => {
    setLoading(true);
    setError(null);

    try {
      let result;
      switch (method) {
        case 'user-based':
          result = await mlService.getUserBasedRecommendations(userId, 5);
          break;
        case 'svd':
          result = await mlService.getSVDRecommendations(userId, 5);
          break;
        case 'rank-based':
          result = await mlService.getRankBasedRecommendations(5, 10);
          break;
        case 'hybrid':
        default:
          result = await mlService.getHybridRecommendations(userId, 5);
          break;
      }

      if (result.status === 'success') {
        setRecommendations(result.recommendations || []);
      } else {
        setError(result.message || 'Failed to load recommendations');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const result = await mlService.getRecommendationStats();
      if (result.status === 'success') {
        setStats(result);
      }
    } catch (err) {
      console.error('Error loading stats:', err);
    }
  };

  const handleMethodChange = (newMethod) => {
    setMethod(newMethod);
  };

  const handleProductClick = (productId) => {
    if (onProductClick) {
      onProductClick(productId);
    }
  };

  const formatProductId = (productId) => {
    // Format product ID for display
    if (typeof productId === 'string') {
      return productId.length > 15 ? productId.substring(0, 12) + '...' : productId;
    }
    return `Product ${productId}`;
  };

  return (
    <div className="recommendation-widget">
      <div className="widget-header">
        <h3>Product Recommendations</h3>
        <div className="method-selector">
          <label htmlFor="method">Method:</label>
          <select 
            id="method" 
            value={method} 
            onChange={(e) => handleMethodChange(e.target.value)}
            disabled={loading}
          >
            <option value="hybrid">Hybrid</option>
            <option value="user-based">User-Based</option>
            <option value="svd">SVD-Based</option>
            <option value="rank-based">Popular</option>
          </select>
        </div>
      </div>

      {loading && (
        <div className="loading-state">
          <div className="spinner"></div>
          <p>Loading recommendations...</p>
        </div>
      )}

      {error && (
        <div className="error-state">
          <p>{error}</p>
          <button onClick={loadRecommendations} className="retry-btn">
            Retry
          </button>
        </div>
      )}

      {!loading && !error && recommendations.length > 0 && (
        <div className="recommendations-list">
          {recommendations.map((productId, index) => (
            <div 
              key={productId} 
              className="recommendation-item"
              onClick={() => handleProductClick(productId)}
            >
              <div className="product-rank">{index + 1}</div>
              <div className="product-info">
                <div className="product-id">{formatProductId(productId)}</div>
                <div className="product-method">{method}</div>
              </div>
              <div className="product-action">
                <button className="view-btn">View</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {!loading && !error && recommendations.length === 0 && (
        <div className="empty-state">
          <p>No recommendations available</p>
          <button onClick={loadRecommendations} className="refresh-btn">
            Refresh
          </button>
        </div>
      )}

      <div className="widget-footer">
        <button onClick={loadRecommendations} className="refresh-btn" disabled={loading}>
          Refresh
        </button>
        <button onClick={loadStats} className="stats-btn">
          Show Stats
        </button>
      </div>

      {stats && (
        <div className="stats-modal">
          <div className="stats-content">
            <h4>Recommendation System Stats</h4>
            <div className="stats-grid">
              <div className="stat-item">
                <label>Total Users:</label>
                <span>{stats.total_users?.toLocaleString() || 'N/A'}</span>
              </div>
              <div className="stat-item">
                <label>Total Products:</label>
                <span>{stats.total_products?.toLocaleString() || 'N/A'}</span>
              </div>
              <div className="stat-item">
                <label>Total Ratings:</label>
                <span>{stats.total_ratings?.toLocaleString() || 'N/A'}</span>
              </div>
              <div className="stat-item">
                <label>Matrix Density:</label>
                <span>{stats.density || 'N/A'}</span>
              </div>
            </div>
            <button onClick={() => setStats(null)} className="close-btn">
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default RecommendationWidget;

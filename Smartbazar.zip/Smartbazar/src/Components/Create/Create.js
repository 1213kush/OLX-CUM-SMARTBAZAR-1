import React, { Fragment, useState, useContext } from "react";
import { Upload, X, AlertCircle, CheckCircle } from "lucide-react";
import "./Create.css";
import Header from "../Header/Header";
import GoLoading from "../Loading/GoLoading";
import { db, storage } from "../../firebase/config";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { AuthContext } from "../../contextStore/AuthContext";
import { useHistory } from "react-router";

const Create = () => {
  const { user } = useContext(AuthContext);
    const history = useHistory();
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [contactPreference, setContactPreference] = useState("email");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [showWhatsApp, setShowWhatsApp] = useState(false);
  const [contactEmail, setContactEmail] = useState("");
  const [showIllegalPopup, setShowIllegalPopup] = useState(false);

  // List of illegal keywords to detect in image names
  const illegalKeywords = [
    'gun', 'guns', 'pistol', 'rifle', 'weapon', 'knife', 'sword', 'bomb', 'explosive',
    'sex', 'sexy', 'porn', 'adult', 'xxx', 'nude', 'naked', 'erotic', 'toy', 'toys',
    'drug', 'drugs', 'cocaine', 'heroin', 'marijuana', 'weed', 'opioid', 'pill',
    'illegal', 'contraband', 'smuggle', 'blackmail', 'fraud', 'scam',
    'tobacco', 'cigarette', 'vape', 'alcohol', 'beer', 'liquor',
    'gambling', 'casino', 'bet', 'betting', 'lottery',
    'hate', 'racist', 'terrorism', 'terrorist', 'extremist'
  ];

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    
    // Check for illegal keywords in file names
    const illegalFiles = files.filter(file => {
      const fileName = file.name.toLowerCase();
      return illegalKeywords.some(keyword => fileName.includes(keyword));
    });
    
    if (illegalFiles.length > 0) {
      setShowIllegalPopup(true);
      e.target.value = ''; // Clear the file input
      return;
    }
    
    if (images.length + files.length > 6) {
      setError("You can upload a maximum of 6 images");
      setTimeout(() => setError(""), 3000);
      return;
    }
    
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length === 0) {
      setError("Please select valid image files");
      setTimeout(() => setError(""), 3000);
      return;
    }
    
    setImages(prevImages => [...prevImages, ...imageFiles]);
    setError("");
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const files = Array.from(e.dataTransfer.files);
      const event = { target: { files: files } };
      handleImageChange(event);
    }
  };

  const removeImage = (index) => {
    setImages(prevImages => prevImages.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (!user) {
      setError("You must be logged in to create a listing");
      return;
    }

    if (images.length < 1) {
      setError("Please upload at least 1 image (maximum 6)");
      return;
    }

    if (!name || !category || !price || !description) {
      setError("Please fill in all required fields");
      return;
    }

    if (contactPreference === "phone" && !phoneNumber) {
      setError("Please provide a phone number for contact");
      return;
    }

    if (contactPreference === "email" && !contactEmail) {
      setError("Please provide an email address for contact");
      return;
    }

    setLoading(true);
    setError("");
    
    try {
      console.log("Starting upload process...");
      console.log("User:", user);
      console.log("Images to upload:", images.length);
      
      // Upload all images and get their URLs
      const imageUrls = [];
      
      for (let i = 0; i < images.length; i++) {
        const image = images[i];
        console.log(`Uploading image ${i + 1}/${images.length}:`, image.name);
        
        try {
          // Create a unique filename with user ID and timestamp
          const imageName = `${user.uid}_${Date.now()}_${image.name}`;
          const storageRef = ref(storage, `images/${imageName}`);
          
          console.log("Storage ref created:", storageRef);
          
          // Upload the file
          console.log("Starting upload...");
          const snapshot = await uploadBytes(storageRef, image);
          console.log("Upload complete:", snapshot);
          
          // Get the download URL
          console.log("Getting download URL...");
          const url = await getDownloadURL(snapshot.ref);
          console.log("Download URL obtained:", url);
          imageUrls.push(url);
          
          // Small delay between uploads to prevent rate limiting
          await new Promise(resolve => setTimeout(resolve, 500));
        } catch (uploadError) {
          console.error("Error uploading image:", uploadError);
          throw new Error(`Failed to upload ${image.name}. ${uploadError.message}`);
        }
      }
      
      console.log("All images uploaded. URLs:", imageUrls);
      
      // Add product to Firestore with array of image URLs
      console.log("Adding product to Firestore...");
      await addDoc(collection(db, "products"), {
        name,
        category,
        price: Number(price),
        description,
        images: imageUrls,
        userId: user.uid,
        createdAt: serverTimestamp(),
        contactPreference,
        phoneNumber: contactPreference === "phone" ? phoneNumber : null,
        showWhatsApp: contactPreference === "phone" ? showWhatsApp : false,
        contactEmail: contactPreference === "email" ? contactEmail : null,
      });
      
      console.log("Product added successfully");
      
      // Show success message
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        // Redirect to home page
        history.push("/");
      }, 2000);
    } catch (error) {
      console.error("Error creating product:", error);
      setError(error.message || "Error creating product. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Fragment>
      <Header />
      {loading && <GoLoading />}
      
      <div className="create-container">
        <div className="create-wrapper">
          {/* Header Section */}
          <div className="create-header">
            <h1 className="create-title">Create New Listing</h1>
            <p className="create-subtitle">Share your product with millions of buyers</p>
          </div>

          {/* Form Container */}
          <div className="form-container">
            {/* Product Details Section */}
            <div className="form-section">
              <h2 className="section-title">Product Details</h2>
              
              <div className="form-group">
                <label className="form-label">
                  Product Name <span className="required">*</span>
                </label>
                <input
                  className="form-input"
                  type="text"
                  placeholder="e.g., iPhone 13 Pro Max"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">
                  Category <span className="required">*</span>
                </label>
                <select
                  className="form-select"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                >
                  <option value="">Select a category</option>
                  
                  <optgroup label="🚗 Vehicles">
                    <option value="Cars">Cars</option>
                    <option value="Bikes">Bikes</option>
                    <option value="Motorcycles">Motorcycles</option>
                    <option value="Scooters">Scooters</option>
                    <option value="Spare Parts">Spare Parts</option>
                    <option value="Bicycles">Bicycles</option>
                  </optgroup>
                  
                  <optgroup label="🏢 Properties">
                    <option value="For Rent: Shops & Offices">For Rent: Shops & Offices</option>
                    <option value="For Sale: Shops & Offices">For Sale: Shops & Offices</option>
                    <option value="PG & Guest Houses">PG & Guest Houses</option>
                  </optgroup>
                  
                  <optgroup label="💻 Electronics & Appliances">
                    <option value="TVs, Video - Audio">TVs, Video - Audio</option>
                    <option value="Kitchen & Other Appliances">Kitchen & Other Appliances</option>
                    <option value="Computers & Laptops">Computers & Laptops</option>
                    <option value="Cameras & Lenses">Cameras & Lenses</option>
                    <option value="Games & Entertainment">Games & Entertainment</option>
                    <option value="Fridges">Fridges</option>
                    <option value="Computer Accessories">Computer Accessories</option>
                    <option value="Hard Disks, Printers & Monitors">Hard Disks, Printers & Monitors</option>
                    <option value="ACs">ACs</option>
                    <option value="Washing Machines">Washing Machines</option>
                  </optgroup>
                  
                  <optgroup label="📱 Mobiles">
                    <option value="Mobile Phones">Mobile Phones</option>
                    <option value="Accessories">Accessories</option>
                    <option value="Tablets">Tablets</option>
                  </optgroup>
                  
                  <optgroup label="🚚 Commercial Vehicles">
                    <option value="Commercial & Other Vehicles">Commercial & Other Vehicles</option>
                    <option value="Spare Parts">Spare Parts</option>
                  </optgroup>
                  
                  <optgroup label="🛋️ Furniture">
                    <option value="Sofa & Dining">Sofa & Dining</option>
                    <option value="Beds & Wardrobes">Beds & Wardrobes</option>
                    <option value="Home Decor & Garden">Home Decor & Garden</option>
                    <option value="Kids Furniture">Kids Furniture</option>
                    <option value="Other Household Items">Other Household Items</option>
                  </optgroup>
                  
                  <optgroup label="👔 Fashion">
                    <option value="Men">Men</option>
                    <option value="Women">Women</option>
                  </optgroup>
                  
                  <optgroup label="📚 Books, Sports & Hobbies">
                    <option value="Books">Books</option>
                    <option value="Gym & Fitness">Gym & Fitness</option>
                    <option value="Musical Instruments">Musical Instruments</option>
                    <option value="Sports Equipment">Sports Equipment</option>
                    <option value="Other Hobbies">Other Hobbies</option>
                  </optgroup>
                  
                  <optgroup label="🎓 Services">
                    <option value="Education & Classes">Education & Classes</option>
                    <option value="Study Material">Study Material</option>
                    <option value="Books">Books</option>
                    <option value="Other">Other</option>
                  </optgroup>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">
                  Price <span className="required">*</span>
                </label>
                <div className="price-input-wrapper">
                  <span className="currency-symbol">₹</span>
                  <input
                    className="form-input price-input"
                    type="number"
                    placeholder="0"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">
                  Description <span className="required">*</span>
                </label>
                <textarea
                  className="form-textarea"
                  rows="5"
                  placeholder="Describe your product in detail..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
                <div className="char-count">{description.length} characters</div>
              </div>
            </div>

            {/* Contact Preferences Section */}
            <div className="form-section">
              <h2 className="section-title">Contact Preferences</h2>
              <p className="section-description">Choose how buyers can contact you about this product</p>
              
              <div className="form-group">
                <label className="form-label">
                  Preferred Contact Method <span className="required">*</span>
                </label>
                <div className="contact-options">
                  <label className="contact-option">
                    <input
                      type="radio"
                      name="contactPreference"
                      value="email"
                      checked={contactPreference === "email"}
                      onChange={(e) => setContactPreference(e.target.value)}
                      className="contact-radio"
                    />
                    <div className="contact-option-content">
                      <span className="contact-icon">📧</span>
                      <div className="contact-text">
                        <strong>Email</strong>
                        <small>Buyers will contact you via email</small>
                      </div>
                    </div>
                  </label>
                  
                  <label className="contact-option">
                    <input
                      type="radio"
                      name="contactPreference"
                      value="phone"
                      checked={contactPreference === "phone"}
                      onChange={(e) => setContactPreference(e.target.value)}
                      className="contact-radio"
                    />
                    <div className="contact-option-content">
                      <span className="contact-icon">📱</span>
                      <div className="contact-text">
                        <strong>Phone/WhatsApp</strong>
                        <small>Buyers will call or message you</small>
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {contactPreference === "email" && (
                <>
                  <div className="form-group">
                    <label className="form-label">
                      Contact Email <span className="required">*</span>
                    </label>
                    <input
                      className="form-input"
                      type="email"
                      placeholder="e.g., seller@example.com"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                    />
                    <small className="form-hint">This email will be used for buyer inquiries about this product</small>
                  </div>
                </>
              )}

              {contactPreference === "phone" && (
                <>
                  <div className="form-group">
                    <label className="form-label">
                      Phone Number <span className="required">*</span>
                    </label>
                    <input
                      className="form-input"
                      type="tel"
                      placeholder="e.g., 9876543210"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      maxLength={10}
                    />
                    <small className="form-hint">10-digit mobile number without country code</small>
                  </div>

                  <div className="form-group">
                    <label className="checkbox-wrapper">
                      <input
                        type="checkbox"
                        checked={showWhatsApp}
                        onChange={(e) => setShowWhatsApp(e.target.checked)}
                        className="checkbox-input"
                      />
                      <span className="checkbox-label">
                        Also available on WhatsApp
                      </span>
                    </label>
                    <small className="form-hint">Buyers can also message you on WhatsApp</small>
                  </div>
                </>
              )}

              {contactPreference === "email" && (
                <div className="form-group">
                  <div className="email-notice">
                    <span className="notice-icon">ℹ️</span>
                    <p>Buyers will contact you through the email associated with your account. Make sure it's up to date!</p>
                  </div>
                </div>
              )}
            </div>

            {/* Images Section */}
            <div className="form-section">
              <h2 className="section-title">Product Images</h2>
              <p className="section-description">Add up to 6 images. First image will be the cover photo.</p>
              
              {/* Image Preview Grid */}
              {images.length > 0 && (
                <div className="image-grid">
                  {images.map((image, index) => (
                    <div key={index} className="image-card">
                      {index === 0 && <span className="cover-badge">Cover</span>}
                      <img
                        alt={`Product ${index + 1}`}
                        src={URL.createObjectURL(image)}
                        className="image-preview"
                      />
                      <button
                        type="button"
                        className="remove-btn"
                        onClick={() => removeImage(index)}
                        aria-label="Remove image"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Upload Area */}
              {images.length < 6 && (
                <div
                  className={`upload-area ${dragActive ? 'drag-active' : ''}`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageChange}
                    className="file-input"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload" className="upload-label">
                    <div className="upload-icon">
                      <Upload size={32} />
                    </div>
                    <div className="upload-text">
                      <span className="upload-title">Click to upload or drag and drop</span>
                      <span className="upload-subtitle">PNG, JPG, GIF up to 10MB</span>
                    </div>
                  </label>
                  <div className="image-counter">
                    {images.length} / 6 images uploaded
                  </div>
                </div>
              )}

              {/* Alert Messages */}
              {error && (
                <div className="alert alert-error">
                  <AlertCircle size={20} />
                  <span>{error}</span>
                </div>
              )}

              {success && (
                <div className="alert alert-success">
                  <CheckCircle size={20} />
                  <span>Listing created successfully!</span>
                </div>
              )}
            </div>

            {/* Submit Button */}
            <div className="form-actions">
              <button
                className="submit-btn"
                onClick={handleSubmit}
                disabled={loading}
              >
                {loading ? 'Publishing...' : 'Publish Listing'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
        }

        .header-placeholder {
          background: white;
          padding: 1rem 2rem;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
          text-align: center;
          font-weight: 600;
        }

        .loading-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.7);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 9999;
        }

        .loading-spinner {
          width: 50px;
          height: 50px;
          border: 4px solid rgba(255, 255, 255, 0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        .create-container {
          max-width: 450px;
          margin: 0 auto;
          padding: 1rem 0.5rem;
        }

        .create-wrapper {
          background: white;
          border-radius: 8px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
          overflow: hidden;
        }

        .create-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 1.5rem 1rem;
          text-align: center;
        }

        .create-title {
          font-size: 1.25rem;
          font-weight: 700;
          margin-bottom: 0.25rem;
        }

        .create-subtitle {
          font-size: 0.8rem;
          opacity: 0.95;
        }

        .form-container {
          padding: 1.25rem;
        }

        .form-section {
          margin-bottom: 1.25rem;
        }

        .section-title {
          font-size: 0.9rem;
          font-weight: 700;
          color: #1a202c;
          margin-bottom: 0.25rem;
        }

        .section-description {
          color: #718096;
          font-size: 0.75rem;
          margin-bottom: 0.75rem;
        }

        .form-group {
          margin-bottom: 0.75rem;
        }

        .form-label {
          display: block;
          font-weight: 600;
          color: #2d3748;
          margin-bottom: 0.25rem;
          font-size: 0.8rem;
        }

        .required {
          color: #e53e3e;
        }

        .form-input,
        .form-select,
        .form-textarea {
          width: 100%;
          padding: 0.5rem 0.75rem;
          border: 2px solid #e2e8f0;
          border-radius: 6px;
          font-size: 0.85rem;
          transition: all 0.2s;
          font-family: inherit;
        }

        .form-input:focus,
        .form-select:focus,
        .form-textarea:focus {
          outline: none;
          border-color: #667eea;
          box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
        }

        .form-select {
          appearance: none;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 10 10'%3E%3Cpath fill='%23718096' d='M5 8L1 4h8z'/%3E%3C/svg%3E");
          background-repeat: no-repeat;
          background-position: right 0.75rem center;
          padding-right: 1.75rem;
        }

        .price-input-wrapper {
          position: relative;
        }

        .currency-symbol {
          position: absolute;
          left: 0.75rem;
          top: 50%;
          transform: translateY(-50%);
          font-weight: 600;
          color: #4a5568;
          font-size: 0.9rem;
        }

        .price-input {
          padding-left: 1.75rem;
        }

        .form-textarea {
          resize: vertical;
          min-height: 60px;
        }

        .char-count {
          text-align: right;
          font-size: 0.7rem;
          color: #718096;
          margin-top: 0.125rem;
        }

        .image-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(75px, 1fr));
          gap: 0.5rem;
          margin-bottom: 0.75rem;
        }

        .image-card {
          position: relative;
          aspect-ratio: 1;
          border-radius: 6px;
          overflow: hidden;
          border: 2px solid #e2e8f0;
          transition: transform 0.2s;
        }

        .image-card:hover {
          transform: scale(1.02);
        }

        .cover-badge {
          position: absolute;
          top: 0.25rem;
          left: 0.25rem;
          background: #667eea;
          color: white;
          padding: 0.125rem 0.375rem;
          border-radius: 3px;
          font-size: 0.6rem;
          font-weight: 600;
          z-index: 2;
        }

        .image-preview {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .remove-btn {
          position: absolute;
          top: 0.25rem;
          right: 0.25rem;
          background: rgba(0, 0, 0, 0.7);
          color: white;
          border: none;
          border-radius: 50%;
          width: 18px;
          height: 18px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.2s;
          z-index: 2;
        }

        .remove-btn:hover {
          background: #e53e3e;
          transform: scale(1.1);
        }

        .upload-area {
          border: 2px dashed #cbd5e0;
          border-radius: 6px;
          padding: 1.25rem;
          text-align: center;
          transition: all 0.3s;
          cursor: pointer;
          background: #f7fafc;
        }

        .upload-area:hover,
        .upload-area.drag-active {
          border-color: #667eea;
          background: #eef2ff;
        }

        .file-input {
          display: none;
        }

        .upload-label {
          cursor: pointer;
          display: block;
        }

        .upload-icon {
          color: #667eea;
          margin-bottom: 0.5rem;
          display: flex;
          justify-content: center;
        }

        .upload-text {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
        }

        .upload-title {
          font-weight: 600;
          color: #2d3748;
          font-size: 0.8rem;
        }

        .upload-subtitle {
          color: #718096;
          font-size: 0.7rem;
        }

        .image-counter {
          margin-top: 0.5rem;
          color: #718096;
          font-size: 0.7rem;
          font-weight: 500;
        }

        .alert {
          display: flex;
          align-items: center;
          gap: 0.375rem;
          padding: 0.5rem;
          border-radius: 6px;
          margin-top: 0.5rem;
          font-size: 0.75rem;
        }

        .alert-error {
          background: #fff5f5;
          color: #c53030;
          border: 1px solid #feb2b2;
        }

        .alert-success {
          background: #f0fff4;
          color: #22543d;
          border: 1px solid #9ae6b4;
        }

        .form-actions {
          margin-top: 1rem;
          padding-top: 1rem;
          border-top: 1px solid #e2e8f0;
        }

        .submit-btn {
          width: 100%;
          padding: 0.625rem 1rem;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          border-radius: 6px;
          font-size: 0.85rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s;
          box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
        }

        .submit-btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 3px 12px rgba(102, 126, 234, 0.4);
        }

        .submit-btn:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }

        @media (max-width: 768px) {
          .create-title {
            font-size: 2rem;
          }

          .form-container {
            padding: 1.5rem;
          }

          .create-header {
            padding: 2rem 1.5rem;
          }

          .image-grid {
            grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
          }
        }

        /* Contact Preferences Styles */
        .contact-options {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }

        .contact-option {
          display: flex;
          align-items: stretch;
          padding: 0.75rem;
          border: 2px solid #e2e8f0;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .contact-option:hover {
          border-color: #cbd5e0;
          background: #f8fafc;
        }

        .contact-option:has(input:checked) {
          border-color: #667eea;
          background: #eef2ff;
        }

        .contact-radio {
          margin-right: 0.75rem;
          margin-top: 0.25rem;
          accent-color: #667eea;
        }

        .contact-option-content {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          flex: 1;
        }

        .contact-icon {
          font-size: 1.5rem;
        }

        .contact-text {
          display: flex;
          flex-direction: column;
          gap: 0.125rem;
        }

        .contact-text strong {
          font-size: 0.85rem;
          color: #2d3748;
        }

        .contact-text small {
          font-size: 0.7rem;
          color: #718096;
        }

        .checkbox-wrapper {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          cursor: pointer;
        }

        .checkbox-input {
          accent-color: #667eea;
          width: 1rem;
          height: 1rem;
        }

        .checkbox-label {
          font-size: 0.8rem;
          color: #2d3748;
          font-weight: 500;
        }

        .form-hint {
          display: block;
          margin-top: 0.25rem;
          font-size: 0.7rem;
          color: #718096;
        }

        .email-notice {
          display: flex;
          align-items: flex-start;
          gap: 0.5rem;
          padding: 0.75rem;
          background: #f0f9ff;
          border: 1px solid #bae6fd;
          border-radius: 6px;
        }

        .notice-icon {
          font-size: 1rem;
          margin-top: 0.125rem;
        }

        .email-notice p {
          margin: 0;
          font-size: 0.75rem;
          color: #0369a1;
          line-height: 1.4;
        }

        /* Illegal Popup Styles */
        .illegal-popup-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.8);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 10000;
          animation: fadeIn 0.3s ease-out;
        }

        .illegal-popup {
          background: white;
          border-radius: 12px;
          padding: 0;
          max-width: 450px;
          width: 90%;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          animation: slideUp 0.3s ease-out;
        }

        .popup-header {
          background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%);
          color: white;
          padding: 1.5rem;
          border-radius: 12px 12px 0 0;
          text-align: center;
        }

        .popup-icon {
          font-size: 3rem;
          margin-bottom: 0.5rem;
          animation: shake 0.5s ease-in-out;
        }

        .popup-header h3 {
          margin: 0;
          font-size: 1.3rem;
          font-weight: 700;
        }

        .popup-content {
          padding: 2rem 1.5rem;
        }

        .popup-content p {
          margin: 0 0 1rem;
          font-size: 1rem;
          color: #374151;
          line-height: 1.6;
          text-align: center;
        }

        .warning-message {
          background: #fef2f2;
          border: 1px solid #fecaca;
          border-radius: 8px;
          padding: 1rem;
          text-align: center;
        }

        .warning-message strong {
          color: #dc2626;
          font-weight: 600;
        }

        .popup-actions {
          padding: 0 1.5rem 1.5rem;
          text-align: center;
        }

        .close-popup-btn {
          background: #dc2626;
          color: white;
          border: none;
          padding: 0.75rem 2rem;
          border-radius: 8px;
          font-size: 1rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .close-popup-btn:hover {
          background: #b91c1c;
          transform: translateY(-1px);
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
      `}</style>
      
      {/* Illegal Content Popup */}
      {showIllegalPopup && (
        <div className="illegal-popup-overlay">
          <div className="illegal-popup">
            <div className="popup-header">
              <div className="popup-icon">⚠️</div>
              <h3>Illegal Content Detected</h3>
            </div>
            <div className="popup-content">
              <p>Your image contains illegal content and cannot be uploaded. Your personal ID card will be used for strict action.</p>
              <div className="warning-message">
                <strong>Warning:</strong> This violates our platform policies and may result in legal consequences.
              </div>
            </div>
            <div className="popup-actions">
              <button 
                className="close-popup-btn"
                onClick={() => {
                  setShowIllegalPopup(false);
                  history.push("/");
                }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </Fragment>
  );
};

export default Create;
import React, { useContext } from 'react';
import { CartContext } from '../../contextStore/CartContext';
import './Cart.css';

function Cart() {
    const { 
        cartItems, 
        removeFromCart, 
        updateQuantity, 
        clearCart, 
        getCartTotal,
        getCartCount 
    } = useContext(CartContext);

    const handleQuantityChange = (productId, newQuantity) => {
        if (newQuantity > 0) {
            updateQuantity(productId, newQuantity);
        }
    };

    if (cartItems.length === 0) {
        return (
            <div className="cart-container">
                <div className="cart-empty">
                    <h2>Your Cart</h2>
                    <div className="empty-cart-icon">🛒</div>
                    <p>Your cart is empty</p>
                    <p>Add some products to get started!</p>
                </div>
            </div>
        );
    }

    return (
        <div className="cart-container">
            <div className="cart-header">
                <h2>Your Cart ({getCartCount()} items)</h2>
                <button className="clear-cart-btn" onClick={clearCart}>
                    Clear Cart
                </button>
            </div>
            
            <div className="cart-items">
                {cartItems.map((item) => (
                    <div key={item.id} className="cart-item">
                        <div className="cart-item-image">
                            <img 
                                src={item.images && item.images.length > 0 ? item.images[0] : ''} 
                                alt={item.name} 
                            />
                        </div>
                        
                        <div className="cart-item-details">
                            <h3 className="cart-item-name">{item.name}</h3>
                            <p className="cart-item-category">{item.category}</p>
                            <p className="cart-item-price">&#x20B9; {item.price}</p>
                        </div>
                        
                        <div className="cart-item-quantity">
                            <button 
                                onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                                className="quantity-btn"
                                disabled={item.quantity <= 1}
                            >
                                -
                            </button>
                            <span className="quantity-display">{item.quantity}</span>
                            <button 
                                onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                                className="quantity-btn"
                            >
                                +
                            </button>
                        </div>
                        
                        <div className="cart-item-total">
                            <p>&#x20B9; {(item.price * item.quantity).toFixed(2)}</p>
                        </div>
                        
                        <div className="cart-item-actions">
                            <button 
                                onClick={() => removeFromCart(item.id)}
                                className="remove-btn"
                                title="Remove item"
                            >
                                🗑️
                            </button>
                        </div>
                    </div>
                ))}
            </div>
            
            <div className="cart-summary">
                <div className="cart-total">
                    <h3>Total: &#x20B9; {getCartTotal().toFixed(2)}</h3>
                </div>
                <div className="cart-actions">
                    <button className="checkout-btn">
                        Proceed to Checkout
                    </button>
                    <button className="continue-shopping-btn">
                        Continue Shopping
                    </button>
                </div>
            </div>
        </div>
    );
}

export default Cart;

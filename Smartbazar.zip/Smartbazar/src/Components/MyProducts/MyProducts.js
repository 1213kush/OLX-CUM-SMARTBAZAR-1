import React, { useState, useEffect, useContext } from "react";
import { Link } from "react-router-dom";
import "./MyProducts.css";
import { db } from "../../firebase/config";
import { collection, query, where, orderBy, getDocs } from "firebase/firestore";
import BarLoading from "../Loading/BarLoading";
import PostCards from "../PostCards/PostCards";
import { AuthContext } from "../../contextStore/AuthContext";
import Header from "../Header/Header";

function MyProducts() {
  const { user } = useContext(AuthContext);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      return;
    }

    const fetchMyProducts = async () => {
      setLoading(true);
      
      try {
        // Fetch products for the current user
        const q = query(
          collection(db, "products"), 
          where("userId", "==", user.uid),
          orderBy("createdAt", "desc")
        );
        const querySnapshot = await getDocs(q);
        
        const userProducts = querySnapshot.docs.map((doc) => ({
          ...doc.data(),
          id: doc.id,
        }));
        
        setProducts(userProducts);
      } catch (error) {
        console.error("Error fetching your products: ", error);
      } finally {
        setLoading(false);
      }
    };

    fetchMyProducts();
  }, [user]);

  if (!user) {
    return (
      <>
        <Header />
        <div className="my-products-container">
          <h2>Please login to view your products</h2>
          <Link to="/login" className="login-link">Go to Login</Link>
        </div>
      </>
    );
  }

  return (
    <>
      <Header />
      <div className="my-products-container">
        <div className="my-products-header">
          <h1>My Products</h1>
          <p>Manage your product listings</p>
          <Link to="/create" className="create-new-btn">
            + Create New Listing
          </Link>
        </div>
        
        {loading ? (
          <BarLoading />
        ) : products.length === 0 ? (
          <div className="no-products">
            <h3>You haven't created any listings yet</h3>
            <p>Start selling by creating your first product listing</p>
            <Link to="/create" className="create-first-btn">
              Create Your First Listing
            </Link>
          </div>
        ) : (
          <div className="products-grid">
            {products.map((product, index) => (
              <div className="product-card-wrapper" key={product.id}>
                <PostCards product={product} index={index} />
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

export default MyProducts;

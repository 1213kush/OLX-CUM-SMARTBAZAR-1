import React from 'react';
import { useHistory } from 'react-router-dom';
import { FaFacebook, FaInstagram, FaYoutube, FaTwitter, FaWhatsapp } from 'react-icons/fa';
import './Footer.css';

function Footer() {
  const history = useHistory();
  
  const handleNavigation = (path) => {
    history.push(path);
  };

  return (
    <div className="footerParentDiv">
      <div className="content">
        <div>
          <div className="heading">
            <p>ABOUT US</p>
          </div>
          <div className="list">
            <ul>
              <li><button className="footer-link" onClick={() => handleNavigation('/smartbazar')}>About SmartBazar</button></li>
              <li><button className="footer-link" onClick={() => handleNavigation('/careers')}>Careers</button></li>
              <li><button className="footer-link" onClick={() => handleNavigation('/contact')}>Contact Us</button></li>
              <li><button className="footer-link" onClick={() => handleNavigation('/upcommings')}>SmartBazar Upcommings</button></li>
            </ul>
          </div>
        </div>
        <div>
          <div className="heading">
            <p>Support</p>
          </div>
          <div className="list">
            <ul>
              <li><button className="footer-link" onClick={() => handleNavigation('/help')}>Help</button></li>
              <li><button className="footer-link" onClick={() => handleNavigation('/sitemap')}>Sitemap</button></li>
              <li><button className="footer-link" onClick={() => handleNavigation('/legal')}>Legal & Privacy information</button></li>
            </ul>
          </div>
        </div>
        <div>
          <div className="heading">
            <p>FOLLOW US</p>
          </div>
          <div className="social-icons">
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="Facebook">
              <FaFacebook />
            </a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="Instagram">
              <FaInstagram />
            </a>
            <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="YouTube">
              <FaYoutube />
            </a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="Twitter">
              <FaTwitter />
            </a>
            <a href="https://whatsapp.com/channel/0029Vb6b9bgJ93wNL276t83a" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="WhatsApp">
              <FaWhatsapp />
            </a>
          </div>
        </div>
      </div>
      <div className="footer">
        <p>Your Campus marketplace</p>
        <p>Free Classifieds in India. © 2025 smartbazar</p>
      </div>
    </div>
  );
}

export default Footer;

import React from 'react';
import { useHistory } from 'react-router-dom';
import Header from '../Components/Header/Header';

function LegalPrivacy() {
  const history = useHistory();

  return (
    <>
      <Header />
      <div style={{ maxWidth: '900px', margin: '0 auto', padding: '40px 20px', fontFamily: 'Arial, sans-serif' }}>
        <h1 style={{ color: '#002f34', fontSize: '2.5rem', marginBottom: '20px' }}>Legal & Privacy Information</h1>
        <p style={{ color: '#555', fontSize: '1.05rem', lineHeight: 1.6, marginBottom: '20px' }}>
          This page provides an overview of how SmartBazar operates from a legal, safety, and
          responsibility point of view. It is a summary of our key terms, guidelines, and
          policies to help you use the platform confidently.
        </p>

        {/* Terms & Conditions */}
        <h2 style={{ color: '#002f34', fontSize: '1.6rem', marginTop: '28px', marginBottom: '12px' }}>1. Terms & Conditions (Summary)</h2>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '12px' }}>
          SmartBazar is an online classified marketplace where individuals and businesses can
          post and browse listings. By accessing or using the platform, you agree to follow
          these terms and only use SmartBazar for lawful and honest purposes.
        </p>
        <ul style={{ color: '#555', lineHeight: 1.6, paddingLeft: '20px', marginBottom: '12px' }}>
          <li>You should be at least 18 years old to create an account and use core services.</li>
          <li>You are responsible for the accuracy of the information you provide.</li>
          <li>Listings must be truthful, clear, and must not mislead buyers.</li>
          <li>SmartBazar may suspend or close accounts involved in fraud, abuse, or policy violations.</li>
        </ul>

        <h3 style={{ color: '#002f34', fontSize: '1.2rem', marginTop: '18px', marginBottom: '8px' }}>Prohibited Use</h3>
        <ul style={{ color: '#555', lineHeight: 1.6, paddingLeft: '20px', marginBottom: '16px' }}>
          <li>Posting illegal, stolen, counterfeit, or restricted items.</li>
          <li>Sharing explicit, harmful, or abusive content.</li>
          <li>Creating multiple fake accounts or manipulating listings.</li>
          <li>Scraping data, hacking, or interfering with platform operations.</li>
        </ul>

        {/* Community Guidelines */}
        <h2 style={{ color: '#002f34', fontSize: '1.6rem', marginTop: '28px', marginBottom: '12px' }}>2. User Guidelines & Community Rules</h2>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '12px' }}>
          To keep SmartBazar safe and useful for everyone, we expect all users to follow basic
          community standards:
        </p>
        <ul style={{ color: '#555', lineHeight: 1.6, paddingLeft: '20px', marginBottom: '12px' }}>
          <li>Be honest in all listings and communications.</li>
          <li>Do not create fake profiles or publish false information.</li>
          <li>Treat other users with respect – harassment, hate speech, and abuse are not allowed.</li>
        </ul>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '12px' }}>
          You may list legitimate items and services such as electronics, vehicles, furniture,
          household goods, and lawful services. The following categories are strictly
          prohibited:
        </p>
        <ul style={{ color: '#555', lineHeight: 1.6, paddingLeft: '20px', marginBottom: '16px' }}>
          <li>Drugs and controlled substances.</li>
          <li>Weapons and explosive materials.</li>
          <li>Counterfeit, stolen, or otherwise illegal goods.</li>
          <li>Adult or illegal services.</li>
        </ul>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '16px' }}>
          Spamming the platform with duplicate or irrelevant ads, or using it only to promote
          external websites, may result in account restrictions or permanent bans.
        </p>

        {/* Return & Refund Policy */}
        <h2 style={{ color: '#002f34', fontSize: '1.6rem', marginTop: '28px', marginBottom: '12px' }}>3. Return & Refund Policy</h2>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '12px' }}>
          SmartBazar is a listing and discovery platform, not an online store. We do not ship
          items, collect payments, or handle delivery logistics. Because of this, SmartBazar
          does not operate its own return or refund system.
        </p>
        <ul style={{ color: '#555', lineHeight: 1.6, paddingLeft: '20px', marginBottom: '16px' }}>
          <li>Any return, replacement, or refund must be agreed directly between buyer and seller.</li>
          <li>SmartBazar does not guarantee product quality, condition, or authenticity.</li>
          <li>Buyers are expected to carefully inspect items and verify details before paying.</li>
        </ul>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '16px' }}>
          If you suspect fraud, you can report it to us at
          {' '}<a href="mailto:support.smartbazar@gmail.com" style={{ color: '#002f34', textDecoration: 'none', fontWeight: 'bold' }}>support.smartbazar@gmail.com</a>.
          We may review the case and take appropriate action on the user&apos;s account.
        </p>

        {/* Safety Tips */}
        <h2 style={{ color: '#002f34', fontSize: '1.6rem', marginTop: '28px', marginBottom: '12px' }}>4. Safety Tips</h2>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '12px' }}>
          Your safety is important. Please follow these recommendations when buying or selling
          through SmartBazar:
        </p>
        <ul style={{ color: '#555', lineHeight: 1.6, paddingLeft: '20px', marginBottom: '16px' }}>
          <li>Prefer meeting in busy public locations such as malls, cafes, or other visible places.</li>
          <li>Do not share sensitive details like bank information, OTPs, government IDs, or home addresses.</li>
          <li>Always check the item&apos;s condition, documents, and serial numbers before paying.</li>
          <li>Be careful with requests for advance payments, very low prices, or urgent pressure to decide.</li>
          <li>Review the seller&apos;s profile, communication style, and history where available.</li>
        </ul>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '16px' }}>
          If you notice suspicious behaviour or potential scams, please let us know at
          {' '}<a href="mailto:support.smartbazar@gmail.com" style={{ color: '#002f34', textDecoration: 'none', fontWeight: 'bold' }}>support.smartbazar@gmail.com</a>.
        </p>

        {/* Legal Disclaimer & Liability */}
        <h2 style={{ color: '#002f34', fontSize: '1.6rem', marginTop: '28px', marginBottom: '12px' }}>5. Legal Disclaimer & Limitation of Liability</h2>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '12px' }}>
          SmartBazar provides a space for users to advertise and discover products and services.
          We are not a party to the actual transaction between buyer and seller and do not
          operate as an online retailer.
        </p>
        <ul style={{ color: '#555', lineHeight: 1.6, paddingLeft: '20px', marginBottom: '16px' }}>
          <li>We do not guarantee the quality, safety, legality, or availability of items listed.</li>
          <li>We do not verify every advertiser, product, or claim.</li>
          <li>We are not responsible for payment issues, delivery problems, or disagreements between users.</li>
          <li>Use of the platform is at your own risk, and SmartBazar is not liable for losses, damage, or disputes arising from user interactions.</li>
        </ul>

        {/* About SmartBazar */}
        <h2 style={{ color: '#002f34', fontSize: '1.6rem', marginTop: '28px', marginBottom: '12px' }}>6. About SmartBazar</h2>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '12px' }}>
          SmartBazar is a digital-first, fast-growing classifieds marketplace built to make
          local buying and selling simple and safe. We operate primarily online, focusing on a
          streamlined experience rather than physical offices.
        </p>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '12px' }}>
          Users can quickly publish ads, browse a wide range of listings, and connect with
          real buyers and sellers in their area. Our goal is to help people exchange goods,
          discover opportunities, and support small businesses through a transparent and
          easy-to-use platform.
        </p>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '20px' }}>
          As SmartBazar grows, we aim to remain one of India&apos;s most trusted and
          community-focused marketplaces, guided by simplicity, safety, and innovation.
        </p>

        <div style={{ marginTop: '32px', textAlign: 'center' }}>
          <button
            onClick={() => history.goBack()}
            style={{
              backgroundColor: 'transparent',
              color: '#002f34',
              border: '1px solid #002f34',
              padding: '10px 25px',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '16px',
              transition: 'all 0.3s ease'
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = '#f0f0f0';
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = 'transparent';
            }}
          >
            Back
          </button>
        </div>
      </div>
    </>
  );
}

export default LegalPrivacy;

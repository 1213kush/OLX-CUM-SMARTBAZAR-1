import React, { Fragment, useContext } from "react";
import Edit from "../Components/Edit/Edit";
import { AuthContext } from "../contextStore/AuthContext";
import Login from "../Components/Login/Login";

const EditPage = () => {
  const { user } = useContext(AuthContext);

  return (
    <Fragment>
      {user ? (
        <Edit />
      ) : (
        <>          
          {alert("You must login first")} <Login />
        </>
      )}
    </Fragment>
  );
};

export default EditPage;

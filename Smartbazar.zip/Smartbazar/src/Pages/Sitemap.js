import React from 'react';
import { useHistory } from 'react-router-dom';
import Header from '../Components/Header/Header';

function Sitemap() {
  const history = useHistory();

  return (
    <>
      <Header />
      <div style={{ maxWidth: '900px', margin: '0 auto', padding: '40px 20px', fontFamily: 'Arial, sans-serif' }}>
        <h1 style={{ color: '#002f34', fontSize: '2.5rem', marginBottom: '20px' }}>Sitemap</h1>
        <p style={{ color: '#555', fontSize: '1.05rem', lineHeight: 1.6, marginBottom: '16px' }}>
          Use this sitemap to quickly navigate to the main sections of SmartBazar.
        </p>

        <ul style={{ color: '#555', lineHeight: 1.8, paddingLeft: '20px', fontSize: '1rem' }}>
          <li>Home</li>
          <li>Login / Signup</li>
          <li>Create Post</li>
          <li>View Listings & Details</li>
          <li>About SmartBazar</li>
          <li>Careers</li>
          <li>Contact Us</li>
          <li>SmartBazar Upcommings</li>
          <li>Help</li>
          <li>Legal & Privacy Information</li>
        </ul>

        <div style={{ marginTop: '32px', textAlign: 'center' }}>
          <button
            onClick={() => history.goBack()}
            style={{
              backgroundColor: 'transparent',
              color: '#002f34',
              border: '1px solid #002f34',
              padding: '10px 25px',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '16px',
              transition: 'all 0.3s ease'
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = '#f0f0f0';
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = 'transparent';
            }}
          >
            Back
          </button>
        </div>
      </div>
    </>
  );
}

export default Sitemap;

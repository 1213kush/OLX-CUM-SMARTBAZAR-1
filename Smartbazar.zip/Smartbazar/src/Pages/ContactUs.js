import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import Header from '../Components/Header/Header';

function ContactUs() {
  const history = useHistory();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState({ success: false, message: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // In a real app, you would typically send this data to a backend service
    // For now, we'll simulate form submission
    setTimeout(() => {
      const mailtoLink = `mailto:ankush.poddar@sankhyasystems.com?subject=${encodeURIComponent(formData.subject || 'Contact Form Submission')}&body=${encodeURIComponent(
        `Name: ${formData.name}\nEmail: ${formData.email}\n\nMessage:\n${formData.message}`
      )}`;
      
      // Open default email client
      window.location.href = mailtoLink;
      
      setSubmitStatus({
        success: true,
        message: 'Thank you for your message! We will get back to you soon.'
      });
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
      
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <>
      <Header />
      <div className="contact-page" style={{
      maxWidth: '800px',
      margin: '0 auto',
      padding: '40px 20px',
      fontFamily: 'Arial, sans-serif'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '40px' }}>
        <h1 style={{ color: '#002f34', fontSize: '2.5rem', marginBottom: '15px' }}>Contact Us</h1>
        <p style={{ color: '#555', fontSize: '1.1rem', maxWidth: '700px', margin: '0 auto' }}>
          Have questions or feedback? We'd love to hear from you. Fill out the form below or email us directly at 
          <a href="mailto:ankush.poddar@sankhyasystems.com" style={{ color: '#002f34', textDecoration: 'none', fontWeight: 'bold' }}>
            {' '}ankush.poddar@sankhyasystems.com
          </a>
        </p>
      </div>

      <div style={{
        backgroundColor: '#f9f9f9',
        padding: '30px',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
      }}>
        {submitStatus.message ? (
          <div style={{
            textAlign: 'center',
            padding: '20px',
            backgroundColor: submitStatus.success ? '#e8f5e9' : '#ffebee',
            color: submitStatus.success ? '#2e7d32' : '#c62828',
            borderRadius: '4px',
            marginBottom: '20px'
          }}>
            {submitStatus.message}
          </div>
        ) : null}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="name" style={{
              display: 'block',
              marginBottom: '8px',
              color: '#333',
              fontWeight: '500'
            }}>
              Full Name *
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              style={{
                width: '100%',
                padding: '12px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                fontSize: '16px',
                boxSizing: 'border-box'
              }}
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="email" style={{
              display: 'block',
              marginBottom: '8px',
              color: '#333',
              fontWeight: '500'
            }}>
              Email Address *
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              style={{
                width: '100%',
                padding: '12px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                fontSize: '16px',
                boxSizing: 'border-box'
              }}
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="subject" style={{
              display: 'block',
              marginBottom: '8px',
              color: '#333',
              fontWeight: '500'
            }}>
              Subject *
            </label>
            <input
              type="text"
              id="subject"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
              style={{
                width: '100%',
                padding: '12px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                fontSize: '16px',
                boxSizing: 'border-box'
              }}
            />
          </div>

          <div style={{ marginBottom: '25px' }}>
            <label htmlFor="message" style={{
              display: 'block',
              marginBottom: '8px',
              color: '#333',
              fontWeight: '500'
            }}>
              Your Message *
            </label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
              rows="6"
              style={{
                width: '100%',
                padding: '12px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                fontSize: '16px',
                resize: 'vertical',
                minHeight: '150px',
                boxSizing: 'border-box',
                fontFamily: 'Arial, sans-serif'
              }}
            ></textarea>
          </div>

          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '15px'
          }}>
            <button
              type="submit"
              disabled={isSubmitting}
              style={{
                backgroundColor: '#002f34',
                color: 'white',
                border: 'none',
                padding: '12px 30px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight: '500',
                transition: 'background-color 0.3s ease',
                opacity: isSubmitting ? 0.7 : 1,
                pointerEvents: isSubmitting ? 'none' : 'auto'
              }}
              onMouseOver={(e) => {
                if (!isSubmitting) e.target.style.backgroundColor = '#004d40';
              }}
              onMouseOut={(e) => {
                if (!isSubmitting) e.target.style.backgroundColor = '#002f34';
              }}
            >
              {isSubmitting ? 'Sending...' : 'Send Message'}
            </button>

            <button
              type="button"
              onClick={() => history.goBack()}
              style={{
                backgroundColor: 'transparent',
                color: '#002f34',
                border: '1px solid #002f34',
                padding: '12px 25px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight: '500',
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.target.backgroundColor = '#f0f0f0';
              }}
              onMouseOut={(e) => {
                e.target.backgroundColor = 'transparent';
              }}
            >
              Go Back
            </button>
          </div>
        </form>
      </div>

      <div style={{
        marginTop: '50px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '25px',
        textAlign: 'center',
        maxWidth: '700px',
        margin: '50px auto 0'
      }}>
        <div style={contactInfoStyle}>
          <div style={iconBoxStyle}>
            <i className="fas fa-envelope" style={{ fontSize: '24px', color: '#002f34' }}></i>
          </div>
          <h3 style={{ color: '#002f34', margin: '15px 0 10px' }}>Email Us</h3>
          <p style={{ color: '#555', margin: '5px 0' }}>
            <a href="mailto:ankush.poddar@sankhyasystems.com" style={{
              color: '#002f34',
              textDecoration: 'none',
              fontWeight: '500'
            }}>
              ankush.poddar@sankhyasystems.com
            </a>
          </p>
        </div>

        <div style={contactInfoStyle}>
          <div style={iconBoxStyle}>
            <i className="fas fa-phone-alt" style={{ fontSize: '24px', color: '#002f34' }}></i>
          </div>
          <h3 style={{ color: '#002f34', margin: '15px 0 10px' }}>Call Us</h3>
          <p style={{ color: '#555', margin: '5px 0' }}>+91 98765 43210</p>
          <p style={{ color: '#777', fontSize: '0.9rem' }}>Mon-Fri from 9am to 6pm IST</p>
        </div>
      </div>
    </div>
    </>
  );
}

const contactInfoStyle = {
  backgroundColor: '#fff',
  padding: '30px 20px',
  borderRadius: '8px',
  boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
  transition: 'transform 0.3s ease',
  ':hover': {
    transform: 'translateY(-5px)'
  }
};

const iconBoxStyle = {
  width: '60px',
  height: '60px',
  backgroundColor: '#e8f5e9',
  borderRadius: '50%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  margin: '0 auto'
};

export default ContactUs;

import React, { Fragment, useContext } from "react";
import MyProducts from "../Components/MyProducts/MyProducts";
import { AuthContext } from "../contextStore/AuthContext";
import Login from "../Components/Login/Login";

const MyProductsPage = () => {
  const { user } = useContext(AuthContext);

  return (
    <Fragment>
      {user ? (
        <MyProducts />
      ) : (
        <>          
          {alert("You must login first to view your products")} <Login />
        </>
      )}
    </Fragment>
  );
};

export default MyProductsPage;

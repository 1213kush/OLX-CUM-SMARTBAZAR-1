import React from 'react';
import { useHistory } from 'react-router';
import Header from '../Components/Header/Header';

function SmartBazar() {
  const history = useHistory();

  const handleGoBack = () => {
    history.goBack();
  };

  return (
    <>
      <Header />
      <div style={{ padding: '40px 20px', maxWidth: '900px', margin: '0 auto' }}>
        <h1 style={{ color: '#002f34', fontSize: '2.5rem', marginBottom: '20px' }}>
          About SmartBazar Group
        </h1>
        <p style={{ color: '#555', fontSize: '1.05rem', lineHeight: 1.6, marginBottom: '16px' }}>
          SmartBazar is a modern classifieds platform where people can buy, sell, and discover
          products and services in their local area. Our mission is to make trading simple,
          safe, and accessible for everyone.
        </p>
        <p style={{ color: '#555', fontSize: '1.05rem', lineHeight: 1.6, marginBottom: '16px' }}>
          From everyday household items to vehicles, real estate, and jobs, SmartBazar connects
          millions of buyers and sellers through an easy-to-use, mobile-friendly experience.
        </p>
        <p style={{ color: '#555', fontSize: '1.05rem', lineHeight: 1.6 }}>
          We focus on trust, transparency, and convenience so that you can spend less time
          searching and more time enjoying what matters most.
        </p>

        {/* Back Button at Bottom */}
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '30px' }}>
          <button 
            onClick={handleGoBack}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '10px 16px',
              backgroundColor: '#002f34',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              transition: 'all 0.3s ease',
              textDecoration: 'none'
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = '#003f44';
              e.target.style.transform = 'translateY(-2px)';
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = '#002f34';
              e.target.style.transform = 'translateY(0)';
            }}
          >
             Back to Home
          </button>
        </div>
      </div>
    </>
  );
}

export default SmartBazar;

import React, { useState } from 'react';
import './MLDemo.css';
import RecommendationWidget from '../Components/Recommendations/RecommendationWidget';
import VisionDetection from '../Components/VisionDetection/VisionDetection';

const MLDemo = () => {
  const [activeTab, setActiveTab] = useState('recommendations');
  const [detectionHistory, setDetectionHistory] = useState([]);

  const handleProductClick = (productId) => {
    console.log('Product clicked:', productId);
    // Navigate to product details or add to cart
  };

  const handleDetectionComplete = (result) => {
    setDetectionHistory(prev => [result, ...prev.slice(0, 4)]); // Keep last 5 results
  };

  return (
    <div className="ml-demo">
      <div className="demo-header">
        <h1>Smartbazar ML Services</h1>
        <p>Experience our AI-powered product recommendations and vision detection</p>
      </div>

      <div className="tab-navigation">
        <button
          className={`tab-btn ${activeTab === 'recommendations' ? 'active' : ''}`}
          onClick={() => setActiveTab('recommendations')}
        >
          🎯 Product Recommendations
        </button>
        <button
          className={`tab-btn ${activeTab === 'vision' ? 'active' : ''}`}
          onClick={() => setActiveTab('vision')}
        >
          👁️ Vision Detection
        </button>
      </div>

      <div className="tab-content">
        {activeTab === 'recommendations' && (
          <div className="recommendations-section">
            <div className="section-header">
              <h2>AI-Powered Product Recommendations</h2>
              <p>Get personalized product suggestions using collaborative filtering and machine learning</p>
            </div>
            
            <div className="demo-grid">
              <RecommendationWidget 
                userId={123} 
                onProductClick={handleProductClick}
              />
              <RecommendationWidget 
                userId={456} 
                onProductClick={handleProductClick}
              />
            </div>

            <div className="info-section">
              <h3>How it works</h3>
              <div className="method-cards">
                <div className="method-card">
                  <h4>User-Based Collaborative Filtering</h4>
                  <p>Finds users with similar preferences and recommends products they liked</p>
                </div>
                <div className="method-card">
                  <h4>SVD Matrix Factorization</h4>
                  <p>Uses singular value decomposition to predict user ratings for unseen products</p>
                </div>
                <div className="method-card">
                  <h4>Rank-Based Recommendations</h4>
                  <p>Suggests popular products with high ratings and sufficient reviews</p>
                </div>
                <div className="method-card">
                  <h4>Hybrid Approach</h4>
                  <p>Combines multiple methods for diverse and accurate recommendations</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'vision' && (
          <div className="vision-section">
            <div className="section-header">
              <h2>AI Vision Detection</h2>
              <p>Detect objects in images using advanced computer vision technology</p>
            </div>

            <div className="demo-grid">
              <div className="vision-demo">
                <VisionDetection onDetectionComplete={handleDetectionComplete} />
              </div>
              
              {detectionHistory.length > 0 && (
                <div className="detection-history">
                  <h3>Recent Detections</h3>
                  <div className="history-list">
                    {detectionHistory.map((result, index) => (
                      <div key={index} className="history-item">
                        <div className="history-info">
                          <span className="detection-count">{result.detection_count} objects</span>
                          <span className="detection-time">
                            {new Date(result.timestamp).toLocaleTimeString()}
                          </span>
                        </div>
                        <div className="detection-classes">
                          {result.detections.slice(0, 3).map((detection, i) => (
                            <span key={i} className="class-tag">
                              {detection.class}
                            </span>
                          ))}
                          {result.detections.length > 3 && (
                            <span className="class-tag more">
                              +{result.detections.length - 3} more
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="info-section">
              <h3>Supported Detection Classes</h3>
              <div className="classes-showcase">
                <div className="class-item">
                  <div className="class-icon">🛒</div>
                  <span>Cart</span>
                </div>
                <div className="class-item">
                  <div className="class-icon">💻</div>
                  <span>Electronics</span>
                </div>
                <div className="class-item">
                  <div className="class-icon">🪑</div>
                  <span>Furniture</span>
                </div>
                <div className="class-item">
                  <div className="class-icon">🛏️</div>
                  <span>Mattress</span>
                </div>
                <div className="class-item">
                  <div className="class-icon">🛋️</div>
                  <span>Sofa</span>
                </div>
                <div className="class-item">
                  <div className="class-icon">🗑️</div>
                  <span>Trash</span>
                </div>
                <div className="class-item">
                  <div className="class-icon">🥡</div>
                  <span>Trash Bags</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="demo-footer">
        <div className="service-status">
          <h3>Service Status</h3>
          <div className="status-grid">
            <div className="status-item">
              <div className="status-indicator online"></div>
              <span>Recommendation API (Port 5001)</span>
            </div>
            <div className="status-item">
              <div className="status-indicator online"></div>
              <span>Vision Detection API (Port 5002)</span>
            </div>
          </div>
        </div>
        
        <div className="api-info">
          <h3>API Documentation</h3>
          <p>Full API documentation available at:</p>
          <div className="api-links">
            <a href="http://localhost:5001" target="_blank" rel="noopener noreferrer">
              Recommendation Service Docs
            </a>
            <a href="http://localhost:5002" target="_blank" rel="noopener noreferrer">
              Vision Service Docs
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MLDemo;

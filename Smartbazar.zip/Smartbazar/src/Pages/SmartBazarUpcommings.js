import React from 'react';
import Header from '../Components/Header/Header';
import Footer from '../Components/Footer/Footer';
import './SmartBazarUpcommings.css';

function SmartBazarUpcommings() {
  return (
    <div className="page-wrapper">
      <Header />
      <main className="upcommings-container">
        <section className="upcommings-hero">
          <h1>SmartBazar Upcommings</h1>
          <p>
            Stay ahead with a preview of upcoming opportunities, features, and experiences
            we are crafting for our SmartBazar community.
          </p>
        </section>

        <section className="upcommings-section">
          <div className="upcommings-section-header">
            <h2>Upcoming Internship Opportunities</h2>
            <p>Grow with SmartBazar through hands-on learning and real product impact.</p>
          </div>
          <div className="upcommings-grid">
            <div className="upcommings-card">
              <h3>Product & Market Research Intern</h3>
              <p>
                Help us understand user needs, analyze marketplace trends, and support
                data-driven product decisions.
              </p>
              <ul>
                <li>Location: Remote / Hybrid</li>
                <li>Duration: 3–6 Months</li>
                <li>Status: Opening Soon</li>
              </ul>
            </div>
            <div className="upcommings-card">
              <h3>Engineering Internship Program</h3>
              <p>
                Collaborate with our engineering team to build scalable, secure, and
                user-friendly SmartBazar experiences.
              </p>
              <ul>
                <li>Tech: React, Firebase, Cloud</li>
                <li>Duration: 3–6 Months</li>
                <li>Status: Applications Opening Soon</li>
              </ul>
            </div>
            <div className="upcommings-card">
              <h3>Customer Experience Intern</h3>
              <p>
                Work closely with our support and operations team to improve buyer and
                seller journeys end-to-end.
              </p>
              <ul>
                <li>Focus: Service Quality & Insights</li>
                <li>Duration: 2–4 Months</li>
                <li>Status: Coming Soon</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="upcommings-section">
          <div className="upcommings-section-header">
            <h2>Upcoming Features</h2>
            <p>Planned enhancements to make SmartBazar smarter and easier to use.</p>
          </div>
          <div className="upcommings-grid">
            <div className="upcommings-card">
              <h3>Smart Recommendations</h3>
              <p>
                Personalized suggestions for buyers and sellers based on activity,
                preferences, and locality.
              </p>
            </div>
            <div className="upcommings-card">
              <h3>Verified Sellers & Listings</h3>
              <p>
                Additional trust badges and verification flows to create a safer
                marketplace.
              </p>
            </div>
            <div className="upcommings-card">
              <h3>Advanced Search & Filters</h3>
              <p>
                Deeper search options, saved filters, and notifications for matching
                listings.
              </p>
            </div>
          </div>
        </section>

        <section className="upcommings-section">
          <div className="upcommings-section-header">
            <h2>Upcoming Functions & Programs</h2>
            <p>Community, events, and strategic programs we are planning.</p>
          </div>
          <div className="upcommings-grid">
            <div className="upcommings-card">
              <h3>Seller Growth Workshops</h3>
              <p>
                Sessions designed to help individual sellers and small businesses
                increase reach and conversions on SmartBazar.
              </p>
            </div>
            <div className="upcommings-card">
              <h3>SmartBazar Community Meetups</h3>
              <p>
                Local and virtual meetups to share success stories, feedback,
                and best practices.
              </p>
            </div>
            <div className="upcommings-card">
              <h3>Partner & Campus Programs</h3>
              <p>
                Collaborations with institutions, startups, and campuses to build
                the next generation of marketplace talent.
              </p>
            </div>
          </div>
        </section>

        <section className="upcommings-section upcommings-more">
          <div className="upcommings-section-header">
            <h2>And More On The Way</h2>
            <p>
              This roadmap will continue to evolve. Check back for new initiatives,
              pilots, and product launches.
            </p>
          </div>
          <div className="upcommings-more-content">
            <p>
              If you are interested in any upcoming opportunity or feature, keep an eye on
              our official announcements and the Careers and Contact pages. We will share
              detailed timelines, eligibility, and application processes as soon as they
              are live.
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}

export default SmartBazarUpcommings;

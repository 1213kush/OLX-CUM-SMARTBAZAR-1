import React from 'react';
import { useHistory } from 'react-router-dom';
import Header from '../Components/Header/Header';

function Help() {
  const history = useHistory();

  return (
    <>
      <Header />
      <div style={{ maxWidth: '900px', margin: '0 auto', padding: '40px 20px', fontFamily: 'Arial, sans-serif' }}>
        <h1 style={{ color: '#002f34', fontSize: '2.5rem', marginBottom: '20px' }}>Help Center</h1>
        <p style={{ color: '#555', fontSize: '1.05rem', lineHeight: 1.6, marginBottom: '16px' }}>
          Welcome to the SmartBazar Help Center. Here you can find quick guidance on how to use
          the platform, manage your account, and stay safe while buying and selling.
        </p>

        <h2 style={{ color: '#002f34', fontSize: '1.5rem', marginTop: '24px', marginBottom: '12px' }}>Getting Started</h2>
        <ul style={{ color: '#555', lineHeight: 1.6, paddingLeft: '20px', marginBottom: '16px' }}>
          <li>Create an account or log in to start posting ads.</li>
          <li>Use the search bar and filters to find products that match your needs.</li>
          <li>Contact sellers through the provided details in the listing.</li>
        </ul>

        <h2 style={{ color: '#002f34', fontSize: '1.5rem', marginTop: '24px', marginBottom: '12px' }}>Safety Tips</h2>
        <ul style={{ color: '#555', lineHeight: 1.6, paddingLeft: '20px', marginBottom: '16px' }}>
          <li>Always meet in public places for transactions where possible.</li>
          <li>Verify product condition and documents before making payment.</li>
          <li>Do not share sensitive personal or banking details with unknown parties.</li>
        </ul>

        <h2 style={{ color: '#002f34', fontSize: '1.5rem', marginTop: '24px', marginBottom: '12px' }}>Need More Help?</h2>
        <p style={{ color: '#555', lineHeight: 1.6, marginBottom: '24px' }}>
          If you have specific questions, please reach out via the Contact Us page, and our team
          will be happy to assist you.
        </p>

        <div style={{ marginTop: '32px', textAlign: 'center' }}>
          <button
            onClick={() => history.goBack()}
            style={{
              backgroundColor: 'transparent',
              color: '#002f34',
              border: '1px solid #002f34',
              padding: '10px 25px',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '16px',
              transition: 'all 0.3s ease'
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = '#f0f0f0';
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = 'transparent';
            }}
          >
            Back
          </button>
        </div>
      </div>
    </>
  );
}

export default Help;

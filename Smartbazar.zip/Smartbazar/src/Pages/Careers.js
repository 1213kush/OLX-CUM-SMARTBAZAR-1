import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import Header from '../Components/Header/Header';

const jobOpenings = [
  {
    id: 1,
    title: 'Senior Frontend Developer',
    type: 'Technical',
    location: 'Bangalore, India',
    description: 'We are looking for an experienced Frontend Developer to join our team. You will be responsible for building user interfaces using React.js and ensuring high performance on both mobile and desktop.',
    requirements: [
      '5+ years of experience with React.js',
      'Strong JavaScript (ES6+) knowledge',
      'Experience with state management (Redux/Context API)',
      'Familiarity with RESTful APIs',
      'Experience with modern frontend build pipelines and tools'
    ]
  },
  {
    id: 2,
    title: 'Backend Engineer - Node.js',
    type: 'Technical',
    location: 'Mumbai, India',
    description: 'Join our backend team to build scalable and high-performance services. You will be working with Node.js, MongoDB, and AWS to deliver robust backend solutions.',
    requirements: [
      '4+ years of Node.js experience',
      'Strong knowledge of NoSQL databases (MongoDB)',
      'Experience with microservices architecture',
      'Familiarity with Docker and Kubernetes',
      'Understanding of CI/CD pipelines'
    ]
  },
  {
    id: 3,
    title: 'Sales Executive',
    type: 'Sales',
    location: 'Delhi, India',
    description: 'We are looking for a dynamic Sales Executive to join our team. You will be responsible for generating leads, building client relationships, and meeting sales targets.',
    requirements: [
      'Proven sales experience in a B2B environment',
      'Excellent communication and negotiation skills',
      'Ability to build and maintain client relationships',
      'Strong problem-solving skills',
      'Willingness to travel as needed'
    ]
  },
  {
    id: 4,
    title: 'Business Development Manager',
    type: 'Sales',
    location: 'Hyderabad, India',
    description: 'Lead our business development efforts by identifying new business opportunities and building strong relationships with potential clients.',
    requirements: [
      '5+ years of experience in business development',
      'Proven track record of meeting sales targets',
      'Strong analytical and strategic thinking skills',
      'Excellent communication and presentation skills',
      'Experience in the tech industry is a plus'
    ]
  }
];

function Careers() {
  const history = useHistory();
  const [activeTab, setActiveTab] = useState('all');
  const [selectedJob, setSelectedJob] = useState(null);

  const filteredJobs = activeTab === 'all' 
    ? jobOpenings 
    : jobOpenings.filter(job => job.type.toLowerCase() === activeTab);

  return (
    <>
      <Header />
      <div className="careers-page" style={{
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '40px 20px',
      fontFamily: 'Arial, sans-serif'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '40px' }}>
        <h1 style={{ color: '#002f34', fontSize: '2.5rem', marginBottom: '15px' }}>Join Our Team</h1>
        <p style={{ color: '#555', fontSize: '1.1rem', maxWidth: '700px', margin: '0 auto' }}>
          At SmartBazar, we're building the future of online classifieds. Join us in our mission to make buying and selling easier for everyone.
        </p>
      </div>

      <div style={{
        display: 'flex',
        justifyContent: 'center',
        marginBottom: '30px',
        flexWrap: 'wrap',
        gap: '10px'
      }}>
        <button 
          onClick={() => setActiveTab('all')}
          style={{
            padding: '10px 20px',
            backgroundColor: activeTab === 'all' ? '#002f34' : '#f7f8f9',
            color: activeTab === 'all' ? 'white' : '#002f34',
            border: '1px solid #002f34',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '16px',
            transition: 'all 0.3s ease',
            margin: '5px'
          }}
        >
          All Positions
        </button>
        <button 
          onClick={() => setActiveTab('technical')}
          style={{
            padding: '10px 20px',
            backgroundColor: activeTab === 'technical' ? '#002f34' : '#f7f8f9',
            color: activeTab === 'technical' ? 'white' : '#002f34',
            border: '1px solid #002f34',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '16px',
            transition: 'all 0.3s ease',
            margin: '5px'
          }}
        >
          Technical
        </button>
        <button 
          onClick={() => setActiveTab('sales')}
          style={{
            padding: '10px 20px',
            backgroundColor: activeTab === 'sales' ? '#002f34' : '#f7f8f9',
            color: activeTab === 'sales' ? 'white' : '#002f34',
            border: '1px solid #002f34',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '16px',
            transition: 'all 0.3s ease',
            margin: '5px'
          }}
        >
          Sales & Business
        </button>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))',
        gap: '25px',
        marginBottom: '40px'
      }}>
        {filteredJobs.map(job => (
          <div 
            key={job.id}
            onClick={() => setSelectedJob(job)}
            style={{
              border: '1px solid #e0e0e0',
              borderRadius: '8px',
              padding: '25px',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              backgroundColor: selectedJob?.id === job.id ? '#f0f8ff' : 'white',
              boxShadow: selectedJob?.id === job.id ? '0 4px 12px rgba(0,0,0,0.1)' : 'none'
            }}
          >
            <h3 style={{ color: '#002f34', marginBottom: '10px' }}>{job.title}</h3>
            <div style={{ 
              display: 'inline-block',
              backgroundColor: job.type === 'Technical' ? '#e3f2fd' : '#e8f5e9',
              color: job.type === 'Technical' ? '#1976d2' : '#2e7d32',
              padding: '4px 12px',
              borderRadius: '12px',
              fontSize: '0.8rem',
              marginBottom: '15px',
              fontWeight: '500'
            }}>
              {job.type}
            </div>
            <p style={{ color: '#555', marginBottom: '15px' }}>
              <i className="fas fa-map-marker-alt" style={{ marginRight: '8px', color: '#757575' }}></i>
              {job.location}
            </p>
            <p style={{ color: '#333', marginBottom: '15px', lineHeight: '1.5' }}>
              {job.description.substring(0, 120)}...
            </p>
            <button 
              style={{
                backgroundColor: 'transparent',
                border: '1px solid #002f34',
                color: '#002f34',
                padding: '8px 16px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '14px',
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.target.style.backgroundColor = '#002f34';
                e.target.style.color = 'white';
              }}
              onMouseOut={(e) => {
                e.target.style.backgroundColor = 'transparent';
                e.target.style.color = '#002f34';
              }}
            >
              View Details
            </button>
          </div>
        ))}
      </div>

      {selectedJob && (
        <div style={{
          backgroundColor: '#f9f9f9',
          padding: '30px',
          borderRadius: '8px',
          marginTop: '20px',
          border: '1px solid #e0e0e0'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            marginBottom: '20px',
            flexWrap: 'wrap',
            gap: '20px'
          }}>
            <div>
              <h2 style={{ color: '#002f34', marginBottom: '10px' }}>{selectedJob.title}</h2>
              <p style={{ color: '#555', marginBottom: '5px' }}>
                <i className="fas fa-map-marker-alt" style={{ marginRight: '8px', color: '#757575' }}></i>
                {selectedJob.location}
              </p>
              <p style={{ color: '#666', fontSize: '0.95rem' }}>
                <i className="fas fa-briefcase" style={{ marginRight: '8px', color: '#757575' }}></i>
                {selectedJob.type} Position
              </p>
            </div>
            <button 
              onClick={() => {
                // In a real app, this would open an application form
                alert('Application form would open here');
              }}
              style={{
                backgroundColor: '#002f34',
                color: 'white',
                border: 'none',
                padding: '10px 25px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '16px',
                transition: 'all 0.3s ease',
                alignSelf: 'center'
              }}
              onMouseOver={(e) => {
                e.target.style.backgroundColor = '#004d40';
              }}
              onMouseOut={(e) => {
                e.target.style.backgroundColor = '#002f34';
              }}
            >
              Apply Now
            </button>
          </div>

          <div style={{ marginTop: '25px' }}>
            <h3 style={{ color: '#002f34', marginBottom: '15px' }}>Job Description</h3>
            <p style={{ color: '#333', lineHeight: '1.7', marginBottom: '20px' }}>
              {selectedJob.description}
            </p>

            <h3 style={{ color: '#002f34', marginBottom: '15px' }}>Requirements</h3>
            <ul style={{ 
              listStyleType: 'none',
              padding: 0,
              margin: 0
            }}>
              {selectedJob.requirements.map((req, index) => (
                <li key={index} style={{
                  padding: '8px 0',
                  borderBottom: '1px solid #eee',
                  display: 'flex',
                  alignItems: 'flex-start'
                }}>
                  <span style={{
                    display: 'inline-block',
                    width: '24px',
                    height: '24px',
                    backgroundColor: '#002f34',
                    color: 'white',
                    borderRadius: '50%',
                    textAlign: 'center',
                    lineHeight: '24px',
                    marginRight: '10px',
                    flexShrink: 0
                  }}>
                    {index + 1}
                  </span>
                  <span style={{ color: '#333', lineHeight: '1.5' }}>{req}</span>
                </li>
              ))}
            </ul>
          </div>

          <div style={{ marginTop: '30px', textAlign: 'center' }}>
            <button 
              onClick={() => setSelectedJob(null)}
              style={{
                backgroundColor: 'transparent',
                border: '1px solid #002f34',
                color: '#002f34',
                padding: '8px 25px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '16px',
                marginRight: '15px',
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.target.style.backgroundColor = '#f0f0f0';
              }}
              onMouseOut={(e) => {
                e.target.style.backgroundColor = 'transparent';
              }}
            >
              Back to Listings
            </button>
            <button 
              onClick={() => {
                // In a real app, this would open an application form
                alert('Application form would open here');
              }}
              style={{
                backgroundColor: '#002f34',
                color: 'white',
                border: 'none',
                padding: '10px 25px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '16px',
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.target.style.backgroundColor = '#004d40';
              }}
              onMouseOut={(e) => {
                e.target.style.backgroundColor = '#002f34';
              }}
            >
              Apply for This Position
            </button>
          </div>
        </div>
      )}

      {!selectedJob && (
        <div style={{
          textAlign: 'center',
          marginTop: '50px',
          padding: '30px',
          backgroundColor: '#f8f9fa',
          borderRadius: '8px'
        }}>
          <h3 style={{ color: '#002f34', marginBottom: '15px' }}>Don't See Your Dream Job?</h3>
          <p style={{ color: '#555', marginBottom: '20px', maxWidth: '700px', marginLeft: 'auto', marginRight: 'auto' }}>
            We're always looking for talented individuals to join our team. Even if you don't see a position that matches your skills, we'd love to hear from you.
          </p>
          <button 
            onClick={() => {
              // In a real app, this would open a general application form
              alert('General application form would open here');
            }}
            style={{
              backgroundColor: '#002f34',
              color: 'white',
              border: 'none',
              padding: '12px 30px',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '16px',
              transition: 'all 0.3s ease'
            }}
            onMouseOver={(e) => {
              e.target.style.backgroundColor = '#004d40';
            }}
            onMouseOut={(e) => {
              e.target.style.backgroundColor = '#002f34';
            }}
          >
            Submit General Application
          </button>
        </div>
      )}

      <div style={{
        marginTop: '60px',
        textAlign: 'center',
        padding: '20px',
        borderTop: '1px solid #e0e0e0'
      }}>
        <p style={{ color: '#666', marginBottom: '10px' }}>Need help with your application?</p>
        <button 
          onClick={() => history.goBack()}
          style={{
            padding: '10px 20px',
            backgroundColor: 'transparent',
            color: '#002f34',
            border: '1px solid #002f34',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '16px',
            transition: 'all 0.3s ease'
          }}
          onMouseOver={(e) => {
            e.target.style.backgroundColor = '#f0f0f0';
          }}
          onMouseOut={(e) => {
            e.target.style.backgroundColor = 'transparent';
          }}
        >
          Back to Home
        </button>
      </div>
    </div>
    </>
  );
}

export default Careers;

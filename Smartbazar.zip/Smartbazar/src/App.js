import React, { useEffect } from "react";
import "./App.css";
import ContextAllPost from "./contextStore/AllPostContext";
import ContextAuth from "./contextStore/AuthContext";
import ContextPost from "./contextStore/PostContext";
import ContextCart from "./contextStore/CartContext";
import { ThemeProvider } from "./contextStore/ThemeContext";
import MainRoutes from "./Routes/MainRoutes";
import mlService from "./Services/MLService";

function App() {
  useEffect(() => {
    // Initialize ML services when app starts
    const initializeMLServices = async () => {
      try {
        console.log('Initializing ML Services...');
        const results = await mlService.initializeServices();
        
        if (results.recommendations?.status === 'success') {
          console.log('✓ Recommendation service initialized');
        }
        
        if (results.vision?.status === 'success') {
          console.log('✓ Vision detection service initialized');
        }
        
        console.log('ML Services initialization complete');
      } catch (error) {
        console.error('Error initializing ML services:', error);
      }
    };

    initializeMLServices();
  }, []);

  return (
    <div>
      <ContextAuth>
        <ContextAllPost>
          <ContextPost>
            <ContextCart>
              <ThemeProvider>
                <MainRoutes />
              </ThemeProvider>
            </ContextCart>
          </ContextPost>
        </ContextAllPost>
      </ContextAuth>
    </div>
  );
}

export default App;

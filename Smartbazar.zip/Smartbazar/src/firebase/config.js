import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyByEjtnFKOHVoNwjsrSSxOgZ18_2V7Z33I",
  authDomain: "smartbazar-b3602.firebaseapp.com",
  projectId: "smartbazar-b3602",
  storageBucket: "smartbazar-b3602.firebasestorage.app",
  messagingSenderId: "731109513658",
  appId: "1:731109513658:web:5115396349525e9621a583",
  measurementId: "G-2G8TMN2HX5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app, "gs://smartbazar-b3602.firebasestorage.app");

export { app, auth, db, storage };
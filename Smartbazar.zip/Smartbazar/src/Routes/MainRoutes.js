import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from '../Pages/Home';
import Signup from '../Pages/Signup';
import Login from '../Pages/Login';
import CreatePost from '../Pages/CreatePost';
import ViewPost from '../Pages/ViewPost';
import ViewMore from '../Pages/ViewMore';
import Careers from '../Pages/Careers';
import ContactUs from '../Pages/ContactUs';
import SmartBazar from '../Pages/SmartBazar';
import SmartBazarUpcommings from '../Pages/SmartBazarUpcommings';
import Help from '../Pages/Help';
import Sitemap from '../Pages/Sitemap';
import LegalPrivacy from '../Pages/LegalPrivacy';
import EditPost from '../Pages/EditPost';
import MyProductsPage from '../Pages/MyProductsPage';
import Cart from '../Components/Cart/Cart';
import MLDemo from '../Pages/MLDemo';

function MainRoutes() {
    return (
        <Router>
            <Switch>
                <Route exact path="/" component={Home} />
                <Route path="/signup" component={Signup} />
                <Route path="/login" component={Login} />
                <Route path="/create" component={CreatePost} />
                <Route path="/view" component={ViewPost} />
                <Route path="/viewmore" component={ViewMore} />
                <Route path="/cart" component={Cart} />
                <Route path="/edit/:id" component={EditPost} />
                <Route path="/myproducts" component={MyProductsPage} />
                <Route path="/careers" component={Careers} />
                <Route path="/contact" component={ContactUs} />
                <Route path="/smartbazar" component={SmartBazar} />
                <Route path="/upcommings" component={SmartBazarUpcommings} />
                <Route path="/help" component={Help} />
                <Route path="/sitemap" component={Sitemap} />
                <Route path="/legal" component={LegalPrivacy} />
                <Route path="/ml-demo" component={MLDemo} />
            </Switch>
        </Router>
    );
}

export default MainRoutes;
